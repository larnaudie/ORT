window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnRegistro").addEventListener("click", registrarTiempo);
    document.querySelector("#btnApariciones").addEventListener("click", cantidadApariciones);
}

let resultado = "";
let contadorMensajes = 0;

function registrarTiempo() {
	let nombre = document.querySelector("#txtNombre").value;
    let tiempo = Number(document.querySelector("#txtTiempo").value);
    let categoria = document.querySelector("#slcCategoria").value;
	let cantidadEspacios = 0;

	if(contadorMensajes < 10){
		for (let i = 0; i < nombre.length; i++) {
			if(nombre.charAt(i)=== " "){
				cantidadEspacios++;
			}
		}
	
		if(nombre.length >=2 && nombre.length <= 40 && nombre.charAt(0) === nombre.charAt(0).toUpperCase() && cantidadEspacios <= 2){
			let segundos = tiempo * 60;
			if(!isNaN(tiempo) && tiempo > 0){
				if(categoria === "senior"){
					tiempo = tiempo - (segundos * 0.1 / 60);
				}else if(categoria === "normal"){
					tiempo = tiempo - (segundos * 0.05 / 60);
				}else{
					tiempo = tiempo;
				}
				resultado += `El competidor ${nombre} hizo un tiempo de ${tiempo}<br>`;
				contadorMensajes++;
			}else{
				resultado += `El tiempo debe de ser un valor numerico y ademas debe ser mayor a 0 <br>`;
				contadorMensajes++;
			}
	
		}else{
			resultado += `Hay uno de estos posibles errores en el ingreso de datos:<br>
			*El nombre ingresado no tiene entre 2 y 40 caracteres<br>
			*El nombre no comienza en mayusculas<br>
			*Hay mas de dos espacios en el nombre ingresado<br>`;
			contadorMensajes++;
		}
		document.querySelector("#pResultado").innerHTML = resultado;
	}else{
		document.querySelector("#pResultado").innerHTML = "Reinicie aplicacion ya el contador llego a " + contadorMensajes;
	}
}

function cantidadApariciones() {
	let texto = document.querySelector("#txtTexto").value;
	let segundaLetra = texto.charAt(1);
	let terceraLetra = texto.charAt(2);
	let textoMay = texto.toUpperCase();
	let segundaLetraMay = segundaLetra.toUpperCase();
	let terceraLetraMay = terceraLetra.toUpperCase();
	let contadorSegundaLetra = 0;
	let contadorTerceraLetra = 0;
	let resultadoApariciones = "";

	for (let i = 0; i < textoMay.length; i++) {
		if(textoMay.charAt(i) === segundaLetraMay){
			contadorSegundaLetra++;
		}
		if(textoMay.charAt(i) === terceraLetraMay){
			contadorTerceraLetra++;
		}
	}
	if(contadorSegundaLetra > contadorTerceraLetra){
		resultadoApariciones = `La segunda letra que es ${segundaLetra} aparece mas veces que la tercera letra ${terceraLetra} en la palabra`;
	}else if(contadorTerceraLetra > contadorSegundaLetra){
		resultadoApariciones = `La tercer letra que es ${terceraLetra} aparece mas veces que la segunda letra ${segundaLetra} en la palabra`;
	}else {
		resultadoApariciones = `La tercer letra que es ${terceraLetra} aparece la misma cantidad de veces que la segunda letra ${segundaLetra} en la palabra`;
	}
	document.querySelector("#pResultado2").innerHTML = resultadoApariciones;
	
}