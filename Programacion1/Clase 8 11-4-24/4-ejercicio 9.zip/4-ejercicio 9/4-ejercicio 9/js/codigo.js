window.addEventListener("load", inicio);

function inicio() {
  // document.querySelector("#btnMultiplicar").addEventListener("click", multiplicarFor);
  document
    .querySelector("#btnMultiplicar")
    .addEventListener("click", multiplicarWhile);
  // document.querySelector("#btnMultiplicar").addEventListener("click", multiplicarDoWhile);
}

// function multiplicarFor() {
//     let numero1 = Number(document.querySelector("#txtNumero1").value);//3
//     let numero2 = Number(document.querySelector("#txtNumero2").value);//4
//     let resultado = 0;//3 -> 6 -> 9 -> 12

//     if(!isNaN(numero1) && !isNaN(numero2)){
//         for(let i = 1; i <= numero2; i++){// 1 -> 2 -> 3 -> 4 -> 5
//             resultado += numero1;
//             console.log(i);
//         }

//         document.querySelector("#pResultado").innerHTML = "FOR <br> El producto de los valores ingresados es: " + resultado;
//     }else{
//         document.querySelector("#pResultado").innerHTML = "FOR <br> El producto no se puede calcular ingrese numero";
//     }
// }

function multiplicarWhile() {
  let numero1 = Number(document.querySelector("#txtNumero1").value); //3
  let numero2 = Number(document.querySelector("#txtNumero2").value); //4
  let resultado = 0; //
  let aux = numero1;
  if (!isNaN(numero1) && !isNaN(numero2)) {
    while (aux > 0) {
      resultado += numero2; // 4 -> 8 -> 12
      aux--; //3 -> 2 -> 1 -> 0
      console.log(numero1);
    }
    document.querySelector(
      "#pResultado"
    ).innerHTML = `WHILE <br> El producto de los valores ${numero1} y ${numero2} es: ${resultado}`;
  } else {
    document.querySelector("#pResultado").innerHTML =
      "FOR <br> El producto no se puede calcular ingrese numero";
  }
}
//-------------------------------------------------------------------------------------------------------------
/*function multiplicarDoWhile() {
  let numero1 = Number(document.querySelector("#txtNumero1").value);
  let numero2 = Number(document.querySelector("#txtNumero2").value);
  let resultado = 0;
  let Mensaje = "WHILE <br>  El producto de los valores es: ";
  do{
    resultado+= numero2;
    numero1--;
    console.log(resultado);
    
  }while (numero1 > 0)
  
  document.querySelector("#pResultado").innerHTML = Mensaje + resultado;
}*/
