window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnFor").addEventListener("click", ejercicio14For);
    document.querySelector("#btnWhile").addEventListener("click", ejercicio14While);
    document.querySelector("#btnDoWhile").addEventListener("click", ejercicio14DoWhile);
}

function ejercicio14For() {
    let numero = Number(document.querySelector("#txtNum").value);
        let cantidadDigitos = 0;
        let mensaje = "";
        if (numero === 0) {
            cantidadDigitos = 1;
            mensaje = "La cantidad de digitos de " + numero + " es " + cantidadDigitos;
        } else {
            for (let i = numero; i >= 1; i = i / 10) {
                cantidadDigitos = cantidadDigitos + 1;
            }
            mensaje = "(FOR)La cantidad de digitos de " + numero + " es " + cantidadDigitos;
        }
        document.querySelector("#pResultado").innerHTML = mensaje;
}

function ejercicio14While() {
    let numero = Number(document.querySelector("#txtNum").value);

        let cantidadDigitos = 0;
        let mensaje = "";
        if (numero === 0) {
            mensaje = "La cantidad de digitos de " + numero + " es 1";
        } else {
            let numeroAux = numero;
            while (numeroAux >= 1) {
                cantidadDigitos = cantidadDigitos + 1;
                numeroAux = numeroAux / 10;
            }
            mensaje = "(WHILE)La cantidad de digitos de " + numero + " es " + cantidadDigitos;
        }
        document.querySelector("#pResultado").innerHTML = mensaje;
}

function ejercicio14DoWhile() {
    let numero = Number(document.querySelector("#txtNum").value);
        let cantidadDigitos = 0;
        let mensaje = "";
        if (numero === 0) {
            mensaje = "La cantidad de digitos de " + tNum + " es 1";
        } else {
            let numeroAux = numero;
            do {
                cantidadDigitos = cantidadDigitos + 1;
                numeroAux = numeroAux / 10;
            } while (numeroAux >= 1);
            mensaje = "(DO-WHILE)La cantidad de digitos de " + numero + " es " + cantidadDigitos;
        }
        document.querySelector("#pResultado").innerHTML = mensaje;
}