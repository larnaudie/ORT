//los array se pueden inicializar vacios nombres = [], equivalente a nombres = new Array(), 
// o con valores adentro como esta representado abajo
//los arrays deben escribirse su nombre de variable con plural, ya que almacenara varios elementos

/*let nombres =["Mauro", "Bruno"];
console.log(nombres.length);*/

//------------------------------------------------------------------------------------------------------------------------

// esta manera sirve para consultar desde la consola el array de nombres, 
// nos lo envuelve en corchetes para ver que es un array, nos dice la cantidad de elementos que hay hasta ese momento, 
// ademas si lo expanidmos desde la consola vemos la posicion de cada uno de estos elementos
//los Arrays como los strings son zero based

/*let nombres =["Mauro", "Bruno"];
console.log(nombres);*/

//------------------------------------------------------------------------------------------------------------------------

//Esto que para nosostros era algo comun, tomar una variable y mandarlo al inner html, ahora es un problema,
//  porque en el html no tengo un control para poder manejar una variable array de esta manera, 
//  nos muestra el listado de elementos separados por una coma, no podemos editarlo, no podemos cambiar el separador, 
//  solo sirve para consultar la informacion pero para eso usariamos la consola misma

/*let nombres =["Mauro", "Bruno"];

document.querySelector("#pResultado").innerHTML = nombres;*/

//como hago para llegar a los strings epecificos dentr de array

/*console.log(nombres[0]);
console.log(nombres[1]);
console.log(nombres[2]);//poscion sin elementos en el array*/

//si yo quiero acceder de alguna manera a todos los elementos del array de manera mas automatizada 
// lo que podemos usar es una repetitiva

/*let nombres =["Mauro", "Bruno"];

for (let i = 0; i < nombres.length; i++) {
    document.querySelector("#pResultado").innerHTML += `* ${nombres[i]} <br> `;
}*/

//------------------------------------------------------------------------------------------------------------------------

//el array puede arrancar vacio y nosotros podriamos agregarle elementos

/*let nombres =["Mauro", "Bruno"];

nombres[2] = "Maxi";*/

//agregando de esta manera a posiciones especificas no tengo limitaciones,
//  por lo tanto dejaria  un monton de espacios vacios entre la ultima posicion y la que yo le paso

//nombres[20] = "Marcelo";

//lo correcto hubiera sido agregarlo a la posicion 3, razonando si mi array tiene 3 elementos, 
// lo cual equivale al length, posicion que no consultariamos porque es la primera vacia, 
// aun asi nos viene bien para que sea la proxima posicion de ingreso

/*nombres[nombres.length] = "Sergio";
nombres[nombres.length] = "Martina";

console.log(nombres);*/


//No pueden haber dos elementos en la misma posicion, si yo asigno un elemento en una posicion que ya tiene un elemento, 
// este se sobreescribe

/*nombres[2] = "Maria";
console.log(nombres);*/

//agregar a la posicion .length es algo que ya esta solucionado en javascript para los array, 
// y para eso existe el metodo push
// push y agregar al .length es equivalente

/*nombres.push("Natalia");
console.log(nombres);*/

// algo que no es tan usado pero tambien sirve es agregar dos elementos atraves de un mismo push

/*nombres.push("Silvia", "Emilia");
console.log(nombres);*/

//----------------------------------------------------------------------------------------------------------------


//En cada pasada por la funcion me genero un nuevo array de nombres, no es que se sobreescribe la posicion CUIDADO

/*function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;
    let nombres = [];

    nombres.push(nombre);
    console.log(nombres);
}*/

//los array van a tender a ser variables globales

/*let nombres = [];

function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;

    nombres.push(nombre);
    console.log(nombres);
}*/

//ESTO NOS genera un problema de que en cada agregada vuelve a mostrar el array completo
//lo podemos visualizar en la consola, consultando la variables
/*let nombres = [];

function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;

    nombres.push(nombre);

    for (let i = 0; i < nombres.length; i++) {
        document.querySelector("#pResultado").innerHTML += `* ${nombres[i]} <br> `;
    }
}*/

//una solucion para eso es limpiar el parrafo antes de cada recorrida

/*let nombres = [];

function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;

    nombres.push(nombre);

    document.querySelector("#pResultado").innerHTML = "";

    for (let i = 0; i < nombres.length; i++) {
        document.querySelector("#pResultado").innerHTML += `* ${nombres[i]} <br> `;
    }
}*/

// me puedo llevar la recorrida para una nueva funcion independiente
/*let nombres = [];

function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;

    nombres.push(nombre);

    document.querySelector("#pResultado").innerHTML = "";

    listarPersonas();
}

function listarPersonas() {
    for (let i = 0; i < nombres.length; i++) {
        document.querySelector("#pResultado").innerHTML += `* ${nombres[i]} <br> `;
    }
}*/

// si vamos a la parte b de este ejercicio 6 donde no podemos agregar nombres que ya existen
//no va a funciona porque mi array inicializado vale 0 y mi condicion equivale a 0 < 0, y eso siempre es falso

/*let nombres = [];

function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;
    
    for (let i = 0; i < nombres.length; i++) {
        if(nombres[i] !== nombre)
        nombres.push(nombre);
    }

    document.querySelector("#pResultado").innerHTML = "";
    console.log(nombres)
    listarPersonas();
}

function listarPersonas() {
    for (let i = 0; i < nombres.length; i++) {
        document.querySelector("#pResultado").innerHTML += `* ${nombres[i]} <br> `;
    }
}*/

//intento inicializar el string para poder evitar que esto arranque vacio, lo cual es una mala solucion, 
// pero sirve para ir probando

/*let nombres = ["a"];

function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;
    let aparecio = false;

    for (let i = 0; i < nombres.length; i++) {
        if(nombres[i] === nombre){
            aparecio = true;
            break;
        }
    }
    if(!aparecio){
        nombres.push(nombre);
    }
    
    document.querySelector("#pResultado").innerHTML = "";
    console.log(nombres)
    listarPersonas();
}

function listarPersonas() {
    for (let i = 0; i < nombres.length; i++) {
        document.querySelector("#pResultado").innerHTML += `* ${nombres[i]} <br> `;
    }
}*/

//ya no necesito agregar un usuario a prepo ya que no tengo la necesidad obligatoria de pasar por la repetitiva
/*let nombres = [];

function agregarNombres() {
    let nombre = document.querySelector("#txtNombre").value;
    let aparecio = false;

    for (let i = 0; i < nombres.length; i++) {
        if(nombres[i] === nombre){
            aparecio = true;
            break;
        }
    }
    if(!aparecio){
        nombres.push(nombre);
    }
    
    document.querySelector("#pResultado").innerHTML = "";
    console.log(nombres)
    listarPersonas();
}

function listarPersonas() {
    for (let i = 0; i < nombres.length; i++) {
        document.querySelector("#pResultado").innerHTML += `* ${nombres[i]} <br> `;
    }
}*/

//refacto final



window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnAgregar").addEventListener("click", tomarValoresAgregarNombresSinRepetir);
  }
  
  let nombres = [];
  
  function tomarValoresAgregarNombresSinRepetir() {
    let nombre = document.querySelector("#txtNombre").value;
    agregarNombresSinRepetir(nombre, nombres);
    listarPersonas();
  }
  
  function listarPersonas() {
    document.querySelector("#pResultado").innerHTML = "";
  
    for (let i = 0; i < nombres.length; i++) {
      document.querySelector("#pResultado").innerHTML += `* ${nombres[i]}<br>`;
    }
  }
  
  function agregarNombresSinRepetir(nombre,lista) {
    let aparecio = false;
  
    for (let i = 0; i < lista.length; i++) {
      if(lista[i] === nombre){
        aparecio = true;
        break;
      }
    }
  
    if(!aparecio){
      lista.push(nombre);
    }
  }