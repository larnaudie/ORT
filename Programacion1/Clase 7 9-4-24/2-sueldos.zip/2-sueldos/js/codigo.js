window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnIngresar").addEventListener("click", sueldos);
}

let totalSueldos = 0;
let cantidadEmpleados = 0;
let sueldoMaximo = Number.NEGATIVE_INFINITY;
let sueldoMinimo = Number.POSITIVE_INFINITY;

function sueldos() {
    let sueldo = Number(document.querySelector("#txtSueldo").value);//"80" -> 80
    
    let promedioSueldos;

    if(!isNaN(sueldo)){
        totalSueldos = totalSueldos + sueldo;
        cantidadEmpleados++;
    
        if(sueldoMaximo < sueldo){//30000 < 10000 -> false
            sueldoMaximo = sueldo;
        }
    
        if(sueldoMinimo > sueldo){
            sueldoMinimo = sueldo;
        }
    
        promedioSueldos = totalSueldos / cantidadEmpleados;
    
    
        document.querySelector("#pResultado").innerHTML = `Total de sueldos a pagar: ${totalSueldos} <br>
        Cantidad de Empleados: ${cantidadEmpleados}<br>
        El sueldo Maximo es: ${sueldoMaximo}<br>
        El sueldo Minimo es: ${sueldoMinimo}<br>
        El promedio es: ${promedioSueldos}`
    } else {
        document.querySelector("#pResultado").innerHTML = "Debe de ingresar valores numericos";
    }

}
