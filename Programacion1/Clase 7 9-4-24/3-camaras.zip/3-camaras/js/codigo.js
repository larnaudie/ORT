window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnComprar").addEventListener("click", comprarCamaras);
    document.querySelector("#btnComprar").setAttribute("disabled", "disabled");
    document.querySelector("#txtCantidadCamaras").setAttribute("disabled", "disabled");
    document.querySelector("#txtNombre").setAttribute("disabled", "disabled");





    document.querySelector("#btnCargarStock").addEventListener("click", cargarStockInicial);
}



let stockRestante;

function cargarStockInicial() {
    let stockInicial = Number(document.querySelector("#txtStockInicial").value);

    if(!isNaN(stockInicial)){
        stockRestante = stockInicial;

        document.querySelector("#btnComprar").removeAttribute("disabled");
        document.querySelector("#txtCantidadCamaras").removeAttribute("disabled");
        document.querySelector("#txtNombre").removeAttribute("disabled");

        document.querySelector("#txtStockInicial").setAttribute("disabled", "disabled");
        document.querySelector("#btnCargarStock").setAttribute("disabled", "disabled");
    }else {
        alert("El stock debe ser numerico");
    }
}


let cantidadCompraMaxCamaras = 0;
let cantidadCompras = 0;
let nombreCompraMaxCamaras = "";

function comprarCamaras() {
    let nombreUsuarioCompra = document.querySelector("#txtNombre").value;
    let cantidadCamarasCompra = Number(document.querySelector("#txtCantidadCamaras").value);

    if(cantidadCamarasCompra <= stockRestante && !isNaN(cantidadCamarasCompra)){
        cantidadCompras++;

        stockRestante = stockRestante - cantidadCamarasCompra;

        if(cantidadCamarasCompra > cantidadCompraMaxCamaras){
            cantidadCompraMaxCamaras = cantidadCamarasCompra;
            nombreCompraMaxCamaras = nombreUsuarioCompra;
        }

        if(stockRestante === 0){
            document.querySelector("#btnComprar").setAttribute("disabled", "disabled");
            document.querySelector("#txtCantidadCamaras").setAttribute("disabled", "disabled");
            document.querySelector("#txtNombre").setAttribute("disabled", "disabled");

            document.querySelector("#txtStockInicial").removeAttribute("disabled");
            document.querySelector("#btnCargarStock").removeAttribute("disabled");
        }

        document.querySelector("#pResultado").innerHTML = `Cantidad compras: ${cantidadCompras}<br>
        stock Restante: ${stockRestante}<br>
        Cantidad Maxima: ${cantidadCompraMaxCamaras}<br>
        Nombre compra Maxima: ${nombreCompraMaxCamaras}<br>`;
    }else{
        document.querySelector("#pResultado").innerHTML = "No hay camaras suficientes para la venta o ingreso un valor no numerico";
    }
}