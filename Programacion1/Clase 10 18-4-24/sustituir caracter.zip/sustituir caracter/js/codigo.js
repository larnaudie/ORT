window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnRemplazar").addEventListener("click", sustituirLetra);
}

function sustituirLetra() {
    let texto = document.querySelector("#txtPalabra").value;
    let caracterOriginal = document.querySelector("#txtCaracterOriginal").value;
    let caracterReemplazo = document.querySelector("#txtCaracterCambio").value;

    let textoReemplazado = "";

    for(let i = 0; i < texto.length; i++) {
        if(texto.charAt(i) === caracterOriginal) {
            textoReemplazado += caracterReemplazo;
        }
        else {
            textoReemplazado += texto.charAt(i);
        }
    }
    document.querySelector("#pResultado").innerHTML = textoReemplazado;
}
