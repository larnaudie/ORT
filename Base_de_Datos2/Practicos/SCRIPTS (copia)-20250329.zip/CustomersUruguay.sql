/* Ejecutar en la DB NorthWind */
USE Northwind
GO
CREATE TABLE CustomersUruguay(UYCustomerID nchar(5) not null,
                              UYCompanyName nvarchar(40) not null,
							  UYDateOfCreation datetime,
							  UYLimit money,
							  UYExiste bit,
							  PRIMARY KEY (UYCustomerID))

GO
INSERT INTO CustomersUruguay VALUES('UY001','Fabrica de Pastas Pato Donald',getdate()-365,500,0),
                                   ('UY002','Vineria El Inmigrante',getdate()-200,600,0),
								   ('UY003','Supermercado El Cocodrilo Holandes',getdate()-180,900,0),
								   ('UY004','Restaurant La Rata Alegre',getdate()-365,1000,0),
								   ('UY005','Charly Good Cocina Vegana',getdate()-365,500,0),
								   ('UY006','Almacen El Gran Bonete',getdate()-30,50,0)
GO
CREATE TABLE ShippersUruguay(UYShipperID int identity(1000,1) not null,
                             UYCompanyName nvarchar(49) not null,
							 UYPhone nvarchar(24),
							 PRIMARY KEY (UYShipperID))
GO
INSERT INTO ShippersUruguay VALUES('CityExpress','29161044'),
                                  ('Transur','29009090'),
								  ('UES','29154432'),
								  ('DAC','24014435')
GO




