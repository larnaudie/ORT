﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Persona: IValidable, IComparable<Persona>

    {
        int id;
        static int ultimoId;
        string nombre;
        DateTime fechaNacimiento;
        string cedula;
        List<Prestamo> prestamos;

        public int Id { get => id; set => id = value; }
        public static int UltimoId { get => ultimoId; set => ultimoId = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public DateTime FechaNacimiento { get => fechaNacimiento; set => fechaNacimiento = value; }
        public string Cedula { get => cedula; set => cedula = value; }

        public Persona(string nombre, DateTime fechaNacimiento, string cedula)
        {
            this.id = ++ultimoId;
            this.nombre = nombre;
            this.fechaNacimiento = fechaNacimiento;
            this.cedula = cedula;
        }

        public Persona() 
        {
            this.id = ++ultimoId;
        }    

        public void Validar()
        {

        }

        public int CompareTo(Persona? other)
        {
            throw new NotImplementedException();
        }
    }
}
