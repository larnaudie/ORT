﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Libro: IValidable, IComparable<Libro>  
    {
        int id;
        static int ultimoId;
        string isbn;
        string nombre;
        string autor;

        public int Id { get => id; set => id = value; }
        public static int UltimoId { get => ultimoId; set => ultimoId = value; }
        public string Isbn { get => isbn; set => isbn = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Autor { get => autor; set => autor = value; }

        public Libro(string isbn, string nombre, string autor)
        {
            this.id = ++ultimoId;
            this.isbn = isbn;
            this.nombre = nombre;
            this.autor = autor;
        }
        public Libro() 
        {
            this.id = ++ultimoId;
        }

        public void Validar()
        {

        }

        public int CompareTo(Libro? other)
        {
            throw new NotImplementedException();
        }

    }
}
