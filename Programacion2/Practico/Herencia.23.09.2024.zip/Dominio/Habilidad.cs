﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Habilidad
    {
        int id;
        static int ultimoId = 0;
        string descripcion;
        Enums.Prioridad prioridadDeHabilidad;

        public int Id { get => id; set => id = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }

        public Habilidad() { }

        public Habilidad(string descripcion, Enums.Prioridad prioridadDeHabilidad)
        {
            this.id = ++ultimoId;
            this.descripcion = descripcion;
            this.prioridadDeHabilidad = prioridadDeHabilidad;   
        }


        public void Validar()
        {
            ValidarDescripcion();   
        }

        public void ValidarDescripcion()
        {
            if (descripcion.Length == 0) throw new Exception("Descripción Vacía");
        }

        public int ValorPrioridad()
        {
            return (int)prioridadDeHabilidad;
        }

        public override bool Equals(object? obj)
        {
            return obj is Habilidad habilidad &&
                  descripcion == habilidad.descripcion;
        }

        public override string ToString()
        {
            return $"{descripcion}";
        }
    }
}
