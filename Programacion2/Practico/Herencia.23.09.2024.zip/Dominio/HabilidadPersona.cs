﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class HabilidadPersona
    {
        int nivel;
        Habilidad habilidad;

        public int Nivel { get => nivel; set => nivel = value; }
        internal Habilidad Habilidad { get => habilidad; set => habilidad = value; }

        public HabilidadPersona(int nivel, Habilidad habilidad)
        {
            this.nivel = nivel;
            this.habilidad = habilidad;
        }

        public void Validar()
        {
            ValidarNivel();
        }

        private void ValidarNivel()
        {
            if (nivel < 0) throw new Exception("Nivel no puede ser negativo");
        }

        public int CalcularResultado()
        {
            return nivel * habilidad.ValorPrioridad();
        }
        
        public override bool Equals(object? obj)
        {
            return obj is HabilidadPersona persona && persona.Habilidad.Equals(this.Habilidad); 
        }
    }
}
