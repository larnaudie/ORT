﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public abstract class Persona
    {
        int id;
        static int ultimoId;
        string nombre;
        List<HabilidadPersona> listaHabilidadPersona = new List<HabilidadPersona>();

        public int Id { get => id;}
        public string Nombre { get => nombre; set => nombre = value; }
        public List<HabilidadPersona> ListaHabilidadPersona { get => listaHabilidadPersona; }

        public Persona(string nombre)
        {
            this.id = ++ultimoId;
            this.nombre = nombre;
        }

        public void Validar()
        {
            ValidarNombre();
        }

        private void ValidarNombre()
        {
            if (nombre.Length < 3)
            {
                throw new Exception("Nombre inválido");
            }
        }


        public void HabilidadPersonaExiste(HabilidadPersona habPersona)
        {
            if (listaHabilidadPersona.Contains(habPersona)) throw new Exception("Habilidad ya existe en persona");
        }

        public override bool Equals(object? obj)
        {
            return obj is Persona persona &&
                   id == persona.id;
        }

        public void AgregarHabilidadPersona(HabilidadPersona habPers)
        {
            try
            {
                habPers.Validar();
                HabilidadPersonaExiste(habPers);
                listaHabilidadPersona.Add(habPers);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
                

        public virtual int Puntaje()
        {
            int total = 0;
            foreach (HabilidadPersona unaHabPers in listaHabilidadPersona)
            {
                total += unaHabPers.CalcularResultado();
            }
            return total;
        }
        public override string ToString()
        {
            return $"Nombre:{nombre.PadRight(20)} Id:{id.ToString().PadLeft(4)} Puntaje:{Puntaje()}";
        }

    }
}
