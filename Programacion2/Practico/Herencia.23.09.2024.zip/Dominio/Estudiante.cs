﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Estudiante: Persona
    {
        int nroEstudiante;

        public int NroEstudiante { get => nroEstudiante; set => nroEstudiante = value; }

        public Estudiante(string nombre, int nroEstudiante): base(nombre)
        {
            this.nroEstudiante = nroEstudiante;
        }
        
        public override string ToString()
        {
            return $"{base.ToString()} Nro de Estudiante:{nroEstudiante}";
        }
    }
}
