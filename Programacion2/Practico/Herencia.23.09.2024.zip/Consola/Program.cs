﻿namespace Consola
{
    using Dominio;
    using System;
    using System.Diagnostics;

    internal class Program
    {

        static Sistema unS = Sistema.Instancia;


        static void Main(string[] args)
        {
            Opciones();
        }
        static void Menu()
        {
            Console.WriteLine("Menu principal. Cero para salir");
            string[] titulos = { "Listar todas las habilidades", "Listar Todas las Personas","Listar Estudiantes","Agregar Estudiante"};

            int opcion = 1;
            foreach (string titulo in titulos)
            {
                Console.WriteLine($"{opcion} - {titulo}");
                opcion++;
            }
        }

        static void Opciones()
        {
            int valor = -1;
            while (valor != 0)
            {
                Console.Clear();
                Menu();
                valor = Utils.LeerNumero("Ingrese opcion");
                switch (valor)
                {
                    case 1:
                        ListarHabilidades();
                        break;
                    case 2:
                        ListarTodos();
                        break;
                    case 3:
                        ListarEstudiantes();
                        break;
                    case 4:
                        AgregarEstudiante();
                        break;
                    default:
                        break;
                }
                Console.WriteLine("Enter para continuar");
                Console.ReadLine();
            }
        }

        static void AgregarEstudiante()
        {
            string nombre = Utils.PedirTexto("Ingrese nombre del estudiante");
            int numeroEstudiante = Utils.LeerNumero("Ingrese número de estudiante");
            try
            {
                Estudiante unE = new Estudiante(nombre, numeroEstudiante);
                unS.AgregarPersona(unE);
                Utils.MensajeConfirmacion($"Estudiante ingresado ok. {unE}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void ListarTodos()
        {
            List<Persona> lista = unS.ObtenerTodos();
            foreach (Persona persona in lista)
            {
                Console.WriteLine(persona.ToString());
            }
        }

        static void ListarEstudiantes()
        {
            List<Persona> lista = unS.ObtenerEstudiantes();
            foreach (Persona persona in lista)
            {
                Console.WriteLine(persona.ToString());
            }
        }


        static void ListarHabilidades()
        {
            List<Habilidad> aux = unS.Habilidades;  
            foreach(Habilidad habilidad in aux)
            {
                Console.WriteLine(habilidad);
            }
        }
    }
}
