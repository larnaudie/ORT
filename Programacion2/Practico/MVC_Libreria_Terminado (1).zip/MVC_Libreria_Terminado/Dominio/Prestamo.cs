﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Prestamo
    {
        DateTime fecha;
        Libro libroPrestado;

        public Prestamo(DateTime fecha, Libro libroPrestado)
        {
            this.fecha = fecha;
            this.libroPrestado = libroPrestado;
        }

        public Prestamo()
        {

        }

        public DateTime Fecha { get => fecha; set => fecha = value; }
        public Libro LibroPrestado { get => libroPrestado; set => libroPrestado = value; }

        public void Validar()
        {
            ValidarLibro();
        }

        public override bool Equals(object? obj)
        {
            if (obj == null) return false;  
            Prestamo otroPre = obj as Prestamo;
            return this.libroPrestado.Equals(otroPre.LibroPrestado);
        }

        private void ValidarLibro()
        {
            if (libroPrestado == null) throw new Exception("Libro no puede ser nulo");
        }

    }
}
