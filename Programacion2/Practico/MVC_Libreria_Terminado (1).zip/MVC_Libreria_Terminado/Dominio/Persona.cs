﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Persona: IValidable, IComparable<Persona>

    {
        int id;
        static int ultimoId;
        string nombre;
        DateTime fechaNacimiento;
        string cedula;
        List<Prestamo> prestamos = new List<Prestamo>();

        public int Id { get => id; set => id = value; }
        public static int UltimoId { get => ultimoId; set => ultimoId = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public DateTime FechaNacimiento { get => fechaNacimiento; set => fechaNacimiento = value; }
        public string Cedula { get => cedula; set => cedula = value; }
        public List<Prestamo> Prestamos { get => prestamos; set => prestamos = value; }

        public Persona(string nombre, DateTime fechaNacimiento, string cedula)
        {
            this.id = ++ultimoId;
            this.nombre = nombre;
            this.fechaNacimiento = fechaNacimiento;
            this.cedula = cedula;
        }

        public Persona() 
        {
            this.id = ++ultimoId;
        }    

        public void AgregarPrestamo(Prestamo unP)
        {
            try
            {
                unP.Validar();
                PrestamoExiste(unP);
                prestamos.Add(unP);

            }
            catch (Exception)
            {

                throw;
            }
        }

        public void PrestamoExiste(Prestamo unP)
        {
            foreach (Prestamo unPre in prestamos)
            {
                if (unPre.Equals(unP)) throw new Exception("Libro ya existe en lista de prestamos.");
            }
        }


        public void Validar()
        {
            ValidarCedula();
            ValidarFechaNacimiento();
        }

        private void ValidarFechaNacimiento()
        {
            if( fechaNacimiento >  DateTime.Today ) throw new Exception("No se puede haber nacido en el futuro.");
        }


        private void ValidarCedula()
        {
            if(cedula.Length < 6) throw new Exception("Cédula con largo inválido.");
            foreach (Char caracter in cedula)
            {
                if(!Char.IsDigit(caracter))
                {
                    throw new Exception("Caracteres inválidos en la Cédula.");
                }
            }
        }

        public override bool Equals(object? obj)
        {
            if (obj == null) return false;  
            Persona persona = obj as Persona;
            return cedula.Equals(persona.Cedula);
        }

        public int CompareTo(Persona? other)
        {
            return nombre.CompareTo(other.Nombre);
            
        }
    }
}
