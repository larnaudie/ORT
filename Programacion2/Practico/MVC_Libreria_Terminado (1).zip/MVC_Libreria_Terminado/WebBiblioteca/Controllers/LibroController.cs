﻿using Dominio;
using Microsoft.AspNetCore.Mvc;

namespace WebBiblioteca.Controllers
{
    public class LibroController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult LibrosOrdenados()
        {
            Sistema unS = Sistema.Instancia;
            return View(unS.DevolverLibroOrdenado());
        }
    }
}
