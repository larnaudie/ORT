﻿using Dominio;
using Microsoft.AspNetCore.Mvc;

namespace WebBiblioteca.Controllers
{
    public class PrestamoController : Controller
    {
        public IActionResult VerPrestamos(int Id)
        {
            Sistema unS = Sistema.Instancia;
            try
            {
                ViewBag.Persona = unS.DevolverPersona(Id);
                ViewBag.Prestamos = unS.VerPrestamosDePersona(Id);
                if (ViewBag.Prestamos.Count == 0)
                {
                    ViewBag.Error = "No hay préstamos asociados a esta persona.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }
            return View();
        }

        public IActionResult GestionarPrestamo()
        {
            Sistema unS = Sistema.Instancia;

            ViewBag.Libros = unS.DevolverLibros();
            ViewBag.Personas = unS.DevolverPersonaOrdenada();
            return View();
        }

        [HttpPost]

        public IActionResult GestionarPrestamo(int IdPersona,int IdLibro)
        {
            Sistema unS = Sistema.Instancia;

            try
            {
                ViewBag.IdPersona = IdPersona;
                ViewBag.IdLibro = IdLibro;
                Persona unaP = unS.DevolverPersona(IdPersona);
                unaP.AgregarPrestamo( new Prestamo(DateTime.Now,unS.DevolverLibro(IdLibro)));
                TempData["Mensaje"] = "Prestamo Gestionado";
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
            }
            return RedirectToAction("GestionarPrestamo");

        }

    }
}
