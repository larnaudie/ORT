﻿using Microsoft.AspNetCore.Mvc;

namespace WebBiblioteca.Controllers
{
    public class InicioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
