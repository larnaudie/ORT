﻿using Dominio;
using Microsoft.AspNetCore.Mvc;

namespace WebBiblioteca.Controllers
{
    public class PersonaController : Controller
    {
        Sistema unS = Sistema.Instancia;


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult PersonasAlfabetico()
        {
            Sistema unS = Sistema.Instancia;
            return View(unS.DevolverPersonaOrdenada());
        }

        public IActionResult AltaPersona()
        {
            return View();
        }

        [HttpPost]

        public IActionResult AltaPersona(Persona unaP)
        {
            try
            {
                unS.AgregarPersona(unaP);
                ViewBag.Mensaje = "Persona correctamente agregada";
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }
            return View(unaP);
        }

        public IActionResult EditarPersona(int Id)
        {
            Persona persona = unS.DevolverPersona(Id);  
            return View(persona);   
        }

        [HttpPost]

        public IActionResult EditarPersona(Persona unaP)
        {
            try
            {
                unaP.Validar();
                Persona persona = unS.DevolverPersona(unaP.Id);
                persona.Nombre = unaP.Nombre;
                persona.FechaNacimiento = unaP.FechaNacimiento;
                persona.Cedula = unaP.Cedula;
                ViewBag.Mensaje = "Cambios realizados con éxito";
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }
            return View(unaP);
        }


    }
}
