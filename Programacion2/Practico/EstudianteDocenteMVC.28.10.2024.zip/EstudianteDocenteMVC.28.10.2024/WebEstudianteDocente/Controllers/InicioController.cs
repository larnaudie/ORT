﻿using Microsoft.AspNetCore.Mvc;

namespace WebEstudianteDocente.Controllers
{
    public class InicioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
