﻿using Microsoft.AspNetCore.Mvc;
using Dominio;

namespace WebEstudianteDocente.Controllers
{
    public class HabilidadController : Controller
    {
        Sistema unS = Sistema.Instancia;

        public IActionResult Index()
        {

            return View(unS.Habilidades);
        }
    }
}
