﻿using Microsoft.AspNetCore.Mvc;
using Dominio;
using System.Security.Cryptography.X509Certificates;

namespace WebEstudianteDocente.Controllers
{
    public class PersonaController : Controller
    {
        Sistema unS = Sistema.Instancia;    

        public IActionResult ListarPersona()
        {
            if(HttpContext.Session.GetString("Usuario") == null)
            {
                return Redirect("/Persona/Login");
            }
            else
            {
                if(HttpContext.Session.GetString("Rol") == "Estudiante")
                {
                    return Redirect("/Persona/Login");
                }
            }
            ViewBag.Titulo = "Listado de Personas";
            return View(unS.ObtenerTodos());
        }

        public IActionResult ListarEstudiante()
        {
            if (HttpContext.Session.GetString("Usuario") == null)
            {
                return Redirect("/Persona/Login");
            }
            ViewBag.Titulo = "Listado de Estudiantes";
            return View("ListarPersona", unS.ObtenerEstudiantes());  
        }

        public IActionResult ListarDocente()
        {
            if (HttpContext.Session.GetString("Usuario") == null)
            {
                return Redirect("/Persona/Login");
            }
            else
            {
                if (HttpContext.Session.GetString("Rol") == "Estudiante")
                {
                    return Redirect("/Persona/Login");
                }
            }
            ViewBag.Titulo = "Listado de Docentes";
            return View("ListarPersona", unS.ObtenerDocentes());
        }


        public IActionResult ListarHabilidadesDePersona(int id)
        {
            if (HttpContext.Session.GetString("Usuario") == null)
            {
                return Redirect("/Persona/Login");
            }
            else
            {
                if (HttpContext.Session.GetString("Rol") == "Estudiante")
                {
                    return Redirect("/Persona/Login");
                }
            }

            ViewBag.Nombre = unS.DevolverNombre(id);
            ViewBag.Lista = unS.DevolverHabilidadPersonaDePersona(id);
            return View();
        }

        public IActionResult AgregarEstudiante()
        {
            if (HttpContext.Session.GetString("Usuario") == null)
            {
                return Redirect("/Persona/Login");
            }
            else
            {
                if (HttpContext.Session.GetString("Rol") == "Estudiante")
                {
                    return Redirect("/Persona/Login");
                }
            }

            return View();
        }

        [HttpPost]

        public IActionResult AgregarEstudiante(Estudiante unE)
        {
            try
            {
                unS.AgregarPersona(unE);
                ViewBag.Mensaje = "Estudiante Agregado con Exito";
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }
            return View(unE);  
        }

        public IActionResult Index(int id)
        {
            Sistema unS = Sistema.Instancia;
            Persona? unaP = unS.DevolverPersona(id);
            ViewBag.Rol = HttpContext.Session.GetString("Rol");
            return View(unaP);
        }


        public IActionResult Login()
        { 
            return View(); 
        }

        [HttpPost]
        
        public IActionResult Login(string Usuario, string Contraseña)
        {
            Sistema unS = Sistema.Instancia;
            Persona? unaP = unS.DevolverPersona(Usuario, Contraseña);
            if(unaP != null)
            {
                HttpContext.Session.SetString("Usuario", unaP.Usuario);
                if(unaP is Estudiante)
                {
                    HttpContext.Session.SetString("Rol", "Estudiante");

                }
                else
                {
                    HttpContext.Session.SetString("Rol", "Docente");
                }
                return RedirectToAction("Index", new { id = unaP.Id });

            }
            else
            {
                ViewBag.Mensaje = "Credenciales Incorrectas";
                return View();
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
