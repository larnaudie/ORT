﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Estudiante: Persona
    {
        int nroEstudiante;

        public int NroEstudiante { get => nroEstudiante; set => nroEstudiante = value; }

        public Estudiante(string nombre, int nroEstudiante,string usr,string pwd): base(nombre, usr, pwd )
        {
            this.nroEstudiante = nroEstudiante;
        }
        
        public Estudiante()
        {

        }

        public override string ToString()
        {
            return $"{base.ToString()}<td>Estudiante:{nroEstudiante}</td>";
        }
    }
}
