﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    internal class Docente : Persona
    {
        int nroDocente;

        public int NroDocente { get => nroDocente; set => nroDocente = value; }

        public Docente(string nombre, int nroDocente,string usr,string pwd): base(nombre,usr,pwd)
        {
            this.nroDocente = nroDocente;
        }

        public Docente()
        {

        }

        public override string ToString()
        {
            return $"{base.ToString()}<td>Docente:{nroDocente}</td>";
        }

        public override int Puntaje()
        {
            return base.Puntaje() + 10;
        }
    }
}
