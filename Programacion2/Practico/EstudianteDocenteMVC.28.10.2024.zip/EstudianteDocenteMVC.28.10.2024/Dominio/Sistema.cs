﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Sistema
    {
        List<Habilidad> habilidades = new List<Habilidad>();
        List<Persona> personas = new List<Persona>();

        public List<Habilidad> Habilidades { get => habilidades; }

        private static Sistema instancia;

        #region Singleton
        public static Sistema Instancia
        {
            get
            {
                if (instancia == null)
                {
                    instancia = new Sistema();
                }
                return instancia;
            }
        }


        private Sistema()
        {
            PrecargarHabilidades();
            PrecargarPersonas();
            PrecargarHabilidadesAPersonas();
        }
        #endregion

        public List<Persona> ObtenerTodos()
        {
            return personas;
        }

        public List<Persona> ObtenerEstudiantes()
        {
            List<Persona> aux = new List<Persona>();

            foreach(Persona unaP in personas)
            {
                if(unaP is Estudiante)
                {
                    aux.Add(unaP);
                }
            }
            return aux;
        }

        public List<Persona> ObtenerDocentes()
        {
            List<Persona> aux = new List<Persona>();

            foreach (Persona unaP in personas)
            {
                if (unaP is Docente)
                {
                    aux.Add(unaP);
                }
            }
            return aux;
        }



        private void AgregarHabilidad(Habilidad habilidad)
        {
            try
            {
                habilidad.Validar();
                VerificarHabilidadNoExiste(habilidad);
                Habilidades.Add(habilidad);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private void PrecargarPersonas()
        {
            AgregarPersona(new Estudiante("Ana Paez", 11231,"aaa","aaa"));
            AgregarPersona(new Estudiante( "Alberto Rodriguez", 11232,"bbb","bbb"));
            AgregarPersona(new Estudiante("Norberto Alvez", 11233,"ccc","ccc"));
            AgregarPersona(new Estudiante("Ana Paez", 11234,"ddd","ddd"));
            AgregarPersona(new Estudiante("Rogelio Suarez", 11235, "eee", "eee" ));
            AgregarPersona(new Estudiante("Roberto Perez", 11236, "fff", "fff"));
            AgregarPersona(new Estudiante("Alfredo Seles", 11237,"ggg","ggg"));
            AgregarPersona(new Estudiante("Virginia Valdazzi", 11238,"hhh","hhh"));
            AgregarPersona(new Docente("Lucrecia Bosch", 5599,"iii","iii"));
            AgregarPersona(new Docente("Ana Paez", 5600,"jjj","jjj"));
            AgregarPersona(new Docente("David Brussa", 5601,"kkk","kkk"));
        }

        private void PrecargarHabilidadesAPersonas()
        {
            DevolverPersona(1).AgregarHabilidadPersona(new HabilidadPersona(4, DevolverHabilidad(1)));
            DevolverPersona(1).AgregarHabilidadPersona(new HabilidadPersona(5, DevolverHabilidad(2)));
            DevolverPersona(1).AgregarHabilidadPersona(new HabilidadPersona(6, DevolverHabilidad(3)));
            DevolverPersona(1).AgregarHabilidadPersona(new HabilidadPersona(7, DevolverHabilidad(4)));
            DevolverPersona(1).AgregarHabilidadPersona(new HabilidadPersona(4, DevolverHabilidad(5)));

            DevolverPersona(2).AgregarHabilidadPersona(new HabilidadPersona(3, DevolverHabilidad(6)));
            DevolverPersona(2).AgregarHabilidadPersona(new HabilidadPersona(3, DevolverHabilidad(4)));
            DevolverPersona(2).AgregarHabilidadPersona(new HabilidadPersona(2, DevolverHabilidad(3)));
            DevolverPersona(2).AgregarHabilidadPersona(new HabilidadPersona(8, DevolverHabilidad(2)));
            DevolverPersona(2).AgregarHabilidadPersona(new HabilidadPersona(9, DevolverHabilidad(1)));

            DevolverPersona(6).AgregarHabilidadPersona(new HabilidadPersona(5, DevolverHabilidad(7)));
            DevolverPersona(6).AgregarHabilidadPersona(new HabilidadPersona(4, DevolverHabilidad(2)));
            DevolverPersona(6).AgregarHabilidadPersona(new HabilidadPersona(9, DevolverHabilidad(3)));
            DevolverPersona(6).AgregarHabilidadPersona(new HabilidadPersona(8, DevolverHabilidad(4)));
            DevolverPersona(6).AgregarHabilidadPersona(new HabilidadPersona(9, DevolverHabilidad(5)));
            DevolverPersona(6).AgregarHabilidadPersona(new HabilidadPersona(1, DevolverHabilidad(14)));

            DevolverPersona(8).AgregarHabilidadPersona(new HabilidadPersona(4, DevolverHabilidad(2)));
            DevolverPersona(8).AgregarHabilidadPersona(new HabilidadPersona(3, DevolverHabilidad(3)));
            DevolverPersona(8).AgregarHabilidadPersona(new HabilidadPersona(8, DevolverHabilidad(5)));
            DevolverPersona(8).AgregarHabilidadPersona(new HabilidadPersona(9, DevolverHabilidad(8)));
            DevolverPersona(8).AgregarHabilidadPersona(new HabilidadPersona(14, DevolverHabilidad(9)));

            DevolverPersona(9).AgregarHabilidadPersona(new HabilidadPersona(4, DevolverHabilidad(9)));
            DevolverPersona(9).AgregarHabilidadPersona(new HabilidadPersona(6, DevolverHabilidad(8)));
            DevolverPersona(9).AgregarHabilidadPersona(new HabilidadPersona(2, DevolverHabilidad(11)));
            DevolverPersona(9).AgregarHabilidadPersona(new HabilidadPersona(2, DevolverHabilidad(12)));
            DevolverPersona(9).AgregarHabilidadPersona(new HabilidadPersona(1, DevolverHabilidad(13)));

            DevolverPersona(5).AgregarHabilidadPersona(new HabilidadPersona(14, DevolverHabilidad(1)));
            DevolverPersona(5).AgregarHabilidadPersona(new HabilidadPersona(11, DevolverHabilidad(2)));
            DevolverPersona(5).AgregarHabilidadPersona(new HabilidadPersona(12, DevolverHabilidad(3)));
            DevolverPersona(5).AgregarHabilidadPersona(new HabilidadPersona(13, DevolverHabilidad(4)));
            DevolverPersona(5).AgregarHabilidadPersona(new HabilidadPersona(6, DevolverHabilidad(8)));

            DevolverPersona(7).AgregarHabilidadPersona(new HabilidadPersona(1, DevolverHabilidad(9)));
            DevolverPersona(7).AgregarHabilidadPersona(new HabilidadPersona(9, DevolverHabilidad(6)));
            DevolverPersona(7).AgregarHabilidadPersona(new HabilidadPersona(8, DevolverHabilidad(5)));
            DevolverPersona(7).AgregarHabilidadPersona(new HabilidadPersona(7, DevolverHabilidad(3)));
            DevolverPersona(7).AgregarHabilidadPersona(new HabilidadPersona(6, DevolverHabilidad(11)));

        }

        private void PrecargarHabilidades()
        {
            try
            {
                AgregarHabilidad(new Habilidad("Liderazgo", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Empatía", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Paciencia", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Resilencia", Enums.Prioridad.BAJA));
                AgregarHabilidad(new Habilidad("Pensamiento crítico", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Capacidad de escucha", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Trabajo en equipo", Enums.Prioridad.ALTA));
                AgregarHabilidad(new Habilidad("Creatividad", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Adaptabilidad", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Gestión del tiempo", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Compromiso con la calidad", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Dominio de idiomas", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Capacidad de gestión de proyectos", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Contabilidad", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Planificación contable", Enums.Prioridad.MEDIA));
                AgregarHabilidad(new Habilidad("Análisis de negocios", Enums.Prioridad.MEDIA));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<HabilidadPersona> DevolverHabilidadPersonaDePersona(int id)
        {
            return DevolverPersona(id).ListaHabilidadPersona;

        }

        public string DevolverNombre(int id)
        {
            string datoADevolver = "";
            Persona? unaP = DevolverPersona(id);
            if(unaP != null)
            {
                datoADevolver = unaP.Nombre;
            }
            return datoADevolver;
        }

        public Habilidad? DevolverHabilidad(int id)
        {
            foreach (Habilidad unaH in habilidades)
            {
                if (unaH.Id == id) return unaH;
            }
            return null;
        }




        public Persona? DevolverPersona(int id)
        {
            foreach (Persona unaP in personas)
            {
                if (unaP.Id == id) return unaP;
            }
            return null;
        }

        public Persona? DevolverPersona(string pNombre)
        {
            foreach (Persona unaP in personas)
            {
                if (unaP.Nombre ==  pNombre) return unaP;
            }
            return null;
        }

        public Persona? DevolverPersona(string usr,string pwd)
        {
            foreach (Persona unaP in personas)
            {
                if (unaP.Usuario == usr && unaP.Contraseña == pwd) return unaP;
            }
            return null;
        }



        public void VerificarHabilidadNoExiste(Habilidad unaH)
        {
            if (habilidades.Contains(unaH))
                throw new Exception("aAbilidad ya existe.");
        }



        public void VerificarPersonaNoExiste(Persona unaP)
        {
            if (personas.Contains(unaP))
                throw new Exception("Persona ya existe.");
        }


        public void AgregarPersona(Persona unaP)
        {
            try
            {
                unaP.Validar();
                VerificarPersonaNoExiste(unaP);
                personas.Add(unaP);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
