
package ordenacion;

import java.util.Arrays;

/**
 *
 * @author Admin
 */
public class Ordenacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int v1[] = {12,6,20,8,3,36,24};
        System.out.println("MIN POS");
        System.out.println("V1: " + Arrays.toString(v1));
        ordenarVectorMinPos(v1);
        System.out.println("V1: " + Arrays.toString(v1));

        int v2[] = {12,6,20,8,3,36,24};
        System.out.println("MIN MAX POS");
        System.out.println("V2: " + Arrays.toString(v2));
        ordenarVectorMinMaxPos(v2);
        System.out.println("V2: " + Arrays.toString(v2));

        int v3[] = {12,6,20,8,3,36,24};
        System.out.println("BUBBLE");
        System.out.println("V3: " + Arrays.toString(v3));
        bubbleSort(v3);
        System.out.println("V3: " + Arrays.toString(v3));
     
        int v4[] = {12,6,20,8,3,36,24};
        System.out.println("BUBBLE MEJORADO");
        System.out.println("V4: " + Arrays.toString(v4));
        bubbleSortMejorado(v4);
        System.out.println("V4: " + Arrays.toString(v4));
        

        int v5[] = {12,6,20,8,3,36,24};
        System.out.println("SELECTION SORT");
        System.out.println("V5: " + Arrays.toString(v5));
        selectionSort(v5);
        System.out.println("V5: " + Arrays.toString(v5));

        int v6[] = {12,6,20,8,3,36,24};
        System.out.println("INSERT SORT");
        System.out.println("V6: " + Arrays.toString(v6));
        insertSort(v6);
        System.out.println("V6: " + Arrays.toString(v6));
        
    }
    
 
    private static int maxPosVec (int[] v, int desde, int hasta){
        int maximo = Integer.MIN_VALUE ;
        int pos = 0;
        for(int i = desde; i <= hasta; i++){
           if(v[i] > maximo){
                maximo = v[i];
                pos = i;
            } 
        }
        return pos;
    }
    
    private static int minPosVec (int[] v, int desde, int hasta){
        int minimo = Integer.MAX_VALUE ;
        int pos = 0;
        for(int i = desde; i <= hasta; i++){
           if(v[i] < minimo){
                minimo = v[i];
                pos = i;
            } 
        }
        return pos;
    }
    
    public static void ordenarVectorMinPos(int []v){
    
        int largo = v.length;
        
        for (int i=0; i < largo -1; i++){
            int minPos = minPosVec(v,i,largo-1);
            if (minPos != i){ // el minimo no esta en la casilla que estoy parado
                int aux = v[i]; //swap de valores
                v[i]=v[minPos];
                v[minPos] = aux;
            }
        }
    }
    
    public static void ordenarVectorMinMaxPos(int []v){
        int i = 0;
        int j = v.length -1;
        
        while (i < j){
            int minPos = minPosVec(v,i,j);
            if (minPos != i){ // el minimo no esta en la casilla que estoy parado
                int aux = v[i]; //swap de valores
                v[i]=v[minPos];
                v[minPos] = aux;
            }
            
            int maxPos = maxPosVec(v,i,j);
            if (maxPos != j) {
                int aux = v[j];
                v[j]=v[maxPos];
                v[maxPos] = aux;
            }
           
            i++;
            j--;
            
        }
        
    }

    public static void bubbleSort(int v[]){
        
        int largo = v.length;
        
        int cantidadPasadas = 0;
        int cantidadComparaciones = 0;
        int cantidadIntercambios = 0;
        
        for (int i=0; i< largo -1; i++){
            cantidadPasadas++;
            
            for (int j = 0; j < largo -1 -i; j++){
                cantidadComparaciones++;
                if (v[j] > v[j+1]){
                    cantidadIntercambios++;
                    int aux = v[j];
                    v[j] = v[j+1];
                    v[j+1] = aux;
                }
            
            }
        }
        
        System.out.println("#Pasadas: " + cantidadPasadas);
        System.out.println("#Comparaciones: " + cantidadComparaciones);
        System.out.println("#Intercambios: " + cantidadIntercambios);
        
    }
    
    
       public static void bubbleSortMejorado(int v[]){
        
        int largo = v.length;
        
        int cantidadPasadas = 0;
        int cantidadComparaciones = 0;
        int cantidadIntercambios = 0;
        
        boolean estaOrdenado = false;
        
        for (int i=0; (i< largo -1)&&(!estaOrdenado); i++){
            cantidadPasadas++;
            estaOrdenado = true;
            for (int j = 0; j < largo -1 -i; j++){
                cantidadComparaciones++;
                if (v[j] > v[j+1]){
                    cantidadIntercambios++;
                    int aux = v[j];
                    v[j] = v[j+1];
                    v[j+1] = aux;
                    estaOrdenado = false;
                }
            
            }
        }
        
        System.out.println("#Pasadas: " + cantidadPasadas);
        System.out.println("#Comparaciones: " + cantidadComparaciones);
        System.out.println("#Intercambios: " + cantidadIntercambios);
        
    }
    
       
    public static void selectionSort(int v[]){
    
        int cantidadPasadas = 0;
        int cantidadComparaciones = 0;
        int cantidadIntercambios = 0;

        
        int largo = v.length;
    
        for (int i = 0; i < largo -1; i++){
            cantidadPasadas++;
            int posMin = i;
            
            for (int j = i+1; j < largo; j++){ // Funcion auxiliar
                cantidadComparaciones++;
                if (v[posMin] > v[j]){
                    posMin = j;
                }
            }
        
            if (posMin != i){
                cantidadIntercambios++;
                int aux = v[i];
                v[i] = v[posMin];
                v[posMin] = aux;
            }
            
        }
    
        System.out.println("#Pasadas: " + cantidadPasadas);
        System.out.println("#Comparaciones: " + cantidadComparaciones);
        System.out.println("#Intercambios: " + cantidadIntercambios);

    
    }
    
    public static void insertSort(int v[]){
   
        int cantidadPasadas = 0;
        int cantidadComparaciones = 0;
        int cantidadIntercambios = 0;

        int largo = v.length;
        
        for (int i = 1; i < largo; i++){
            cantidadPasadas++;
            int insert = v[i]; //elemento que "levanto"
            
            int j = i -1;
        
            while (j >=0 && (insert < v[j])){
                cantidadComparaciones++;
                v[j+1] = v[j];
                cantidadIntercambios++;
                j--;
            }
            cantidadIntercambios++;
            v[j+1] = insert;
        }
        
        
        System.out.println("#Pasadas: " + cantidadPasadas);
        System.out.println("#Comparaciones: " + cantidadComparaciones);
        System.out.println("#Intercambios: " + cantidadIntercambios);

    
    }
    
    
}
