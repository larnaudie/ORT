
package TADs;


public class NodoDoble {

    private int dato;
    private NodoDoble sig;
    private NodoDoble ant;

    //Constructor
    public NodoDoble(int n){
        this.dato=n;
        this.sig=null;
        this.ant=null;
    }

    //Dato
    public void setDato(int d){
        this.dato=d;
    }
    public int getDato(){
        return this.dato;
    }

    //Siguiente
    public void setSig(NodoDoble s){
        this.sig=s;
    }
    public NodoDoble getSig(){
        return this.sig;
    }
        public NodoDoble getAnt() {
        return ant;
    }

    public void setAnt(NodoDoble ant) {
        this.ant = ant;
    }
}
