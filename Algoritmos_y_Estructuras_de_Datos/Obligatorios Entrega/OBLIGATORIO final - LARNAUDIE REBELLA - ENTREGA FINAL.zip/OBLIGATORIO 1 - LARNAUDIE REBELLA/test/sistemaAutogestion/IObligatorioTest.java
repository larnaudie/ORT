/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package sistemaAutogestion;

import java.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author pesce
 */
public class IObligatorioTest {

    private Sistema miSistema;

    public IObligatorioTest() {
        miSistema = new Sistema();
    }

    @Before
    public void setUp() {
        miSistema = new Sistema();
        miSistema.crearSistemaDeGestion();
    }

    //TESTEO REQUERIMIENTO 1.1 
    @Test
    public void testCrearSistemaDeGestion() {

        Retorno retorno = miSistema.crearSistemaDeGestion();

        assertEquals(Retorno.ok().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.2 - OK 
    @Test
    public void testRegistrarSalaOK() {
        Retorno retorno = miSistema.registrarSala("Sala Aire", 80);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("Sala Fuego", 150);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("Sala Agua", 200);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("Sala Tierra", 100);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("Sala Elemento", 1); //CASO BORDE - CAPACIDAD 1 (tenía que ser mayor a 0)
        assertEquals(Retorno.ok().resultado, retorno.resultado);
    }

    /*
    //TESTEO REQUERIMIENTO 1.2 - ERROR1 - ESTE TEST DA ERROR (rojo) PORQUE LOS ULTIMOS TRES CASOS, PERMITEN OBSERVAR QUE EL PROGRAMA DIFERENCIA MAYÚSCULAS Y MINÚSCULAS, ASÍ COMO ESPACIOS EXTRAS
    //ESTO NOS PERMITIÓ DAR CUENTA DE QUE ES NECESARIO QUE EL SISTEMA NO DISTINGA MAYÚSCULAS DE MINÚSCULAS, PARA EVITAR NOMBRES REPETIDOS DE SALAS.
    @Test
    public void testRegistrarSalaERROR1() {
        miSistema.registrarSala("Sala Aire", 100);
        
        Retorno retorno = miSistema.registrarSala("Sala Aire", 80); //ERROR POR IGUAL NOMBRE
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        
        retorno = miSistema.registrarSala("sala aire", 200);
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        
        retorno = miSistema.registrarSala("Sala Aire ", 60);
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        
        retorno = miSistema.registrarSala("sALA aIRE", 150);
        assertEquals(Retorno.error1().resultado, retorno.resultado);
    }
     */
    //TESTEO REQUERIMIENTO 1.2 - ERROR1 - LUEGO DE CONTROLAR QUE NO SE DISTINGA MAY DE MIN EN REGISTRO SALA
    @Test
    public void testRegistrarSalaERROR1() {
        miSistema.registrarSala("Sala Aire", 100);

        Retorno retorno = miSistema.registrarSala("Sala Aire", 80); //ERROR POR IGUAL NOMBRE
        assertEquals(Retorno.error1().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("sala aire", 200);
        assertEquals(Retorno.error1().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("Sala Aire ", 60);
        assertEquals(Retorno.error1().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("sALA aIRE", 150);
        assertEquals(Retorno.error1().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.2 - ERROR2 - CAPACIDAD ES MENOR O IGUAL A 0
    @Test
    public void testRegistrarSalaERROR2() {

        Retorno retorno = miSistema.registrarSala("Sala Aire", 0);
        assertEquals(Retorno.error2().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("Sala Fuego ", -1);
        assertEquals(Retorno.error2().resultado, retorno.resultado);

        retorno = miSistema.registrarSala("Sala Viento ", -2);
        assertEquals(Retorno.error2().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.3 - OK 
    @Test
    public void testEliminarSalaOK() {
        //Completar para primera entrega
        Retorno retorno = miSistema.registrarSala("Sala Espacio", 500);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.eliminarSala("Sala Espacio");
        assertEquals(Retorno.ok().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.3 - ERROR1 
    @Test
    public void testEliminarSalaERROR1() {
        //Completar para primera entrega
        Retorno retorno = miSistema.registrarSala("Sala Zitarrosa", 500);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.eliminarSala("Sala Espacio");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.4 - OK 
    @Test
    public void testRegistrarEventoOK() {

        miSistema.registrarSala("Sala Viento", 100);

        LocalDate fecha = LocalDate.of(2025, 5, 15);
        Retorno retorno = miSistema.registrarEvento("AAQ23", "Noche de gala", 50, fecha);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        LocalDate fecha1 = LocalDate.of(2025, 4, 20);
        retorno = miSistema.registrarEvento("ABC12", "Baile gitano", 1, fecha1);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        LocalDate fecha2 = LocalDate.of(2025, 3, 13);
        retorno = miSistema.registrarEvento("XYZ34", "Bingo", 90, fecha2);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        LocalDate fecha3 = LocalDate.of(2025, 2, 3);
        retorno = miSistema.registrarEvento("LMN567", "Reunión empresarial", 30, fecha3);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        /*fecha = LocalDate.of(2026, 2, 3);
        retorno = miSistema.registrarEvento("LXX567", "Reunión empresarial", 101, fecha);
        assertEquals(Retorno.ok().resultado, retorno.resultado); - ARROJA ERROR 3 POR AFORO MAYOR A CAPACIDAD SALA (C-100 / AFORO 101 - BORDE)*/

 /*fecha = LocalDate.of(2024, 2, 3);
        retorno = miSistema.registrarEvento("LMN327", "Festejo aniversario", 0, fecha);
        assertEquals(Retorno.ok().resultado, retorno.resultado); - ARROJA ERROR 1 POR AFORO IGUAL A 0*/
 /*
        fecha = LocalDate.of(2025, 1, 3);
        retorno = miSistema.registrarEvento("AAQ23", "Reunión empresarial", 30, fecha);
        assertEquals(Retorno.ok().resultado, retorno.resultado); - CON ESTE EJEMPLO COMPROBAMOS QUE NOS TIRA ERROR 1 POR REPETIRSE CÓDIGO DE EVENTO*/
    }

    //TESTEO REQUERIMIENTO 1.4 - ERROR1 
    //SE ASUME QUE EL CÓDIGO DEL EVENTO NO ES CASE SENSITIVE, POR LO TANTO AAQ123 ES DIFERENTE A aaq123.
    @Test
    public void testRegistrarEventoERROR1() {

        miSistema.registrarSala("Sala Baile", 200);
        LocalDate fecha1 = LocalDate.of(2025, 6, 15);
        LocalDate fecha2 = LocalDate.of(2026, 6, 15);
        LocalDate fecha5 = LocalDate.of(2025, 11, 15);
        LocalDate fecha6 = LocalDate.of(2026, 3, 15);
        LocalDate fecha7 = LocalDate.of(2025, 2, 13);

        miSistema.registrarEvento("AAQ23", "Bailamos", 90, fecha1);
        miSistema.registrarEvento("ZZZ12", "Lectura compartida", 100, fecha2);

        Retorno retorno = miSistema.registrarEvento("AAQ23", "Noche de gala", 50, fecha5);
        assertEquals(Retorno.error1().resultado, retorno.resultado);

        retorno = miSistema.registrarEvento("ZZZ12", "Noche de gala", 50, fecha6);
        assertEquals(Retorno.error1().resultado, retorno.resultado);

        retorno = miSistema.registrarEvento("ZZZ12", "Té", 150, fecha7);
        assertEquals(Retorno.error1().resultado, retorno.resultado);

        /*fecha = LocalDate.of(2025, 7, 20);
        retorno = miSistema.registrarEvento("aaq23", "Baile gitano", 120, fecha);
        assertEquals(Retorno.error1().resultado, retorno.resultado); - CON ESTE ARROJA ERROR PORQUE EN REALIDAD NO ES CÓDIGO REPETIDO (SE DETALLA ARRIBA NO CASE SENSITIVE) */
    }

    //TESTEO REQUERIMIENTO 1.4 - ERROR2 - AFORO NECESARIO MENOR IGUAL QUE 0
    @Test
    public void testRegistrarEventoERROR2() {

        miSistema.registrarSala("Sala Baile", 200);
        LocalDate fecha5 = LocalDate.of(2025, 11, 15);
        LocalDate fecha6 = LocalDate.of(2026, 3, 15);

        Retorno retorno = miSistema.registrarEvento("AAQ23", "Noche de gala", 0, fecha5);
        assertEquals(Retorno.error2().resultado, retorno.resultado);

        retorno = miSistema.registrarEvento("ZZZ12", "Noche de gala", -1, fecha6);
        assertEquals(Retorno.error2().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.4 - ERROR3 - SALAS NO DISPONIBLES PARA ESA FECHA CON AFORO SUFICIENTE
    @Test
    public void testRegistrarEventoERROR3() {

        miSistema.registrarSala("Sala Eventos", 100);
        LocalDate fecha1 = LocalDate.of(2025, 12, 15);
        LocalDate fecha2 = LocalDate.of(2026, 12, 15);

        Retorno retorno1 = miSistema.registrarEvento("AAQ23", "Noche de gala", 100, fecha1);
        assertEquals(Retorno.ok().resultado, retorno1.resultado);

        //misma fecha
        Retorno retorno2 = miSistema.registrarEvento("AB7DG", "Evento", 90, fecha1);
        assertEquals(Retorno.error3().resultado, retorno2.resultado);

        //aforo insuficiente fecha disponible
        Retorno retorno3 = miSistema.registrarEvento("A456SD", "Fiesta", 101, fecha2);
        assertEquals(Retorno.error3().resultado, retorno3.resultado);

        //aforo insuficiente y misma fecha
        Retorno retorno4 = miSistema.registrarEvento("ALLL80", "Reunión", 100, fecha1);
        assertEquals(Retorno.error3().resultado, retorno4.resultado);
    }

    //TESTEO REQUERIMIENTO 1.5 - OK
    @Test
    public void testRegistrarClienteOK() {
        //Completar para primera entrega
        Retorno retorno = miSistema.registrarCliente("45678914", "Juan Perez");
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.registrarCliente("36498751", "ana rodriguez");
        assertEquals(Retorno.ok().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.5 - ERROR1
    //Asumismos que la cedula es valida siendo numerica y con 8 digitos
    @Test
    public void testRegistrarClienteERROR1() {
        //Completar para primera entrega
        //Test con 9 digitos
        Retorno retorno = miSistema.registrarCliente("456789147", "Julio Cesar");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        //Test con 7 digitos
        retorno = miSistema.registrarCliente("4567891", "Marco Aurelio");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        //Test con 8 letras
        retorno = miSistema.registrarCliente("asdfghjk", "Cleopatra Nilo");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        //Test con letras y numeros
        retorno = miSistema.registrarCliente("1234ghjk", "Alejandro Magno");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        //Test con simbolos
        retorno = miSistema.registrarCliente("!¡?¿#@_-", "Pompeyo Magno");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        //Test con simbolos y letras
        retorno = miSistema.registrarCliente("!@#abcde", "Trajano Romano");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        //Test con simbolos y numeros
        retorno = miSistema.registrarCliente("!1234?86", "Marcus Ulpius Traianus");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
        //Test con simbolos, numeros y letras
        retorno = miSistema.registrarCliente("!1234abc", "Escipion El Africano");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.5 - ERROR2
    @Test
    public void testRegistrarClienteERROR2() {
        //Completar para primera entrega
        Retorno retorno = miSistema.registrarCliente("45678914", "Juan Perez");
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        retorno = miSistema.registrarCliente("45678914", "Juan Perez");
        assertEquals(Retorno.error2().resultado, retorno.resultado);

    }

// TESTEO REQUERIMIENTO 1.6 - OK
    @Test
    public void testComprarEntradaOK() {
        miSistema.registrarCliente("12345678", "Juan");
        miSistema.registrarCliente("87654321", "Ana");
        miSistema.registrarSala("Sala Baile", 200);
        LocalDate fecha1 = LocalDate.of(2025, 3, 17);
        miSistema.registrarEvento("EVT001", "Concierto", 10, fecha1);
        Retorno retorno = miSistema.comprarEntrada("12345678", "EVT001");
        assertEquals(Retorno.Resultado.OK, retorno.resultado);
    }

    // TESTEO REQUERIMIENTO 1.6 - ERROR1: Cliente no existe
    @Test
    public void testComprarEntradaERROR1() {
        miSistema.registrarCliente("12345678", "Juan");
        miSistema.registrarCliente("87654321", "Ana");
        miSistema.registrarSala("Sala Baile", 200);
        LocalDate fecha1 = LocalDate.of(2025, 3, 17);
        miSistema.registrarEvento("EVT001", "Concierto", 10, fecha1);
        Retorno retorno = miSistema.comprarEntrada("22222222", "EVT001");
        assertEquals(Retorno.Resultado.ERROR_1, retorno.resultado);
    }

    // TESTEO REQUERIMIENTO 1.6 - ERROR2: Evento no existe
    @Test
    public void testComprarEntradaERROR2() {
        miSistema.registrarCliente("12345678", "Juan");
        miSistema.registrarCliente("87654321", "Ana");
        miSistema.registrarSala("Sala Baile", 200);
        LocalDate fecha1 = LocalDate.of(2025, 3, 17);
        miSistema.registrarEvento("EVT001", "Concierto", 10, fecha1);
        Retorno retorno = miSistema.comprarEntrada("12345678", "EVT009");
        assertEquals(Retorno.Resultado.ERROR_2, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.7 - OK
    @Test
    public void testEliminarEventoOK() {
        miSistema.registrarSala("S1", 200);
        miSistema.registrarEvento("E1", "Concierto", 100, LocalDate.of(2025, 7, 15));
        Retorno retorno = miSistema.eliminarEvento("E1");
        assertEquals(Retorno.ok().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.7 - ERROR1: NO EXISTE EVENTO
    @Test
    public void testEliminarEventoERROR1() {
        miSistema.registrarSala("S1", 200);
        miSistema.registrarEvento("E1", "Concierto", 100, LocalDate.of(2025, 7, 15));
        Retorno retorno = miSistema.eliminarEvento("E2");
        retorno = miSistema.eliminarEvento("E3");
        assertEquals(Retorno.error1().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.7 - ERROR2: EVENTO TIENE ENTRADAS VENDIDAS
    @Test
    public void testEliminarEventoERROR2() {
        miSistema.registrarCliente("12345678", "Juan");
        miSistema.registrarSala("S1", 200);
        miSistema.registrarEvento("E1", "Concierto", 100, LocalDate.of(2025, 7, 15));
        miSistema.comprarEntrada("12345678", "E1");
        miSistema.registrarEvento("E2", "Concierto", 100, LocalDate.of(2025, 7, 18));
        miSistema.comprarEntrada("12345678", "E2");

        Retorno retorno = miSistema.eliminarEvento("E1");
        assertEquals(Retorno.error2().resultado, retorno.resultado);
    }
    //TESTEO REQUERIMIENTO 1.8 OK

    @Test
    public void testDevolverEntradaOK() {
        miSistema.registrarCliente("12345678", "Natalia");
        miSistema.registrarCliente("87654321", "Carlos");
        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarEvento("E001", "Obra de teatro", 100, LocalDate.of(2025, 7, 15));
        // Compra Natalia
        miSistema.comprarEntrada("12345678", "E001");
        // Carlos queda en lista de espera
        miSistema.comprarEntrada("87654321", "E001");
        // Natalia devuelve su entrada → Carlos debería recibirla
        Retorno retorno = miSistema.devolverEntrada("12345678", "E001");
        assertEquals(Retorno.ok().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.8 ERROR1: CLIENTE NO EXISTE
    @Test
    public void testDevolverEntradaERROR1() {
        miSistema.registrarCliente("12345678", "Natalia");
        miSistema.registrarEvento("E001", "Concierto", 100, LocalDate.of(2025, 7, 15));
        miSistema.comprarEntrada("12345678", "E001");
        Retorno retorno = miSistema.devolverEntrada("87654321", "E001"); // Cliente no registrado
        assertEquals(Retorno.error1().resultado, retorno.resultado);
    }

    @Test//TESTEO REQUERIMIENTO 1.8 ERROR2: EVENTO NO EXISTE
    public void testDevolverEntradaERROR2() {

        miSistema.registrarCliente("12345678", "Natalia");
        miSistema.registrarCliente("87654321", "Carlos");
        miSistema.registrarSala("Sala A", 100);
        miSistema.registrarEvento("E001", "Obra de teatro", 100, LocalDate.of(2025, 7, 15));
        // Compra Natalia
        miSistema.comprarEntrada("12345678", "E001");
        // Carlos queda en lista de espera
        miSistema.comprarEntrada("87654321", "E001");
        // Natalia devuelve su entrada → Carlos debería recibirla
        Retorno retorno = miSistema.devolverEntrada("12345678", "E005");
        assertEquals(Retorno.error2().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 1.9 - OK 
    @Test
    public void testCalificarEventoOk() {
        miSistema.registrarSala("Sala Astronomia", 200);
        LocalDate fecha1 = LocalDate.of(2025, 3, 15);
        LocalDate fecha2 = LocalDate.of(2025, 3, 16);
        miSistema.registrarCliente("11111111", "María");
        miSistema.registrarEvento("EVT1", "Fiesta", 5, fecha1);
        miSistema.registrarEvento("EVT2", "Teatro", 5, fecha2);

        // Calificación válida
        Retorno retorno = miSistema.calificarEvento("11111111", "EVT1", 9, "Excelente evento");

        // Debe retornar OK
        assertEquals(Retorno.ok().resultado, retorno.resultado);

    }

    //TESTEO REQUERIMIENTO 1.9 - Error1
    @Test
    public void testCalificarEventoERROR1() {
        miSistema.registrarSala("Sala Astronomia", 200);
        LocalDate fecha = LocalDate.of(2025, 3, 15);
        miSistema.registrarEvento("EVT1", "Fiesta", 5, fecha);

        // Cliente "22222222" no fue registrado
        Retorno retorno = miSistema.calificarEvento("22222222", "EVT1", 8, "Muy bueno");

        assertEquals(Retorno.error1().resultado, retorno.resultado); // Cliente no existe
    }

    //TESTEO REQUERIMIENTO 1.9 - Error2
    @Test
    public void testCalificarEventoERROR2() {
        miSistema.registrarSala("Sala Astronomia", 200);
        LocalDate fecha = LocalDate.of(2025, 3, 15);
        miSistema.registrarCliente("33333333", "Laura");

        // Evento "EVTNOEXISTE" no fue registrado
        Retorno retorno = miSistema.calificarEvento("33333333", "EVTNOEXISTE", 7, "Estuvo bien");

        assertEquals(Retorno.error2().resultado, retorno.resultado); // Evento no existe
    }

    //TESTEO REQUERIMIENTO 1.9 - Error3
    @Test
    public void testCalificarEventoERROR3() {
        miSistema.registrarSala("Sala Astronomia", 200);
        LocalDate fecha = LocalDate.of(2025, 3, 15);
        miSistema.registrarCliente("44444444", "Sofía");
        miSistema.registrarEvento("EVT3", "Charla", 5, fecha);

        // Puntaje inválido (0)
        Retorno retorno = miSistema.calificarEvento("44444444", "EVT3", 0, "Comentario");

        assertEquals(Retorno.error3().resultado, retorno.resultado); // Puntaje inválido
    }

    //TESTEO REQUERIMIENTO 1.9 - Error4
    @Test
    public void testCalificarEventoERROR4() {
        miSistema.registrarSala("Sala Astronomia", 200);
        LocalDate fecha = LocalDate.of(2025, 3, 15);
        miSistema.registrarCliente("55555555", "Diego");
        miSistema.registrarEvento("EVT4", "Conferencia", 5, fecha);

        // Primera calificación válida
        miSistema.calificarEvento("55555555", "EVT4", 9, "Muy interesante");

        // Segunda calificación al mismo evento por el mismo cliente
        Retorno retorno = miSistema.calificarEvento("55555555", "EVT4", 8, "Aún mejor");

        assertEquals(Retorno.error4().resultado, retorno.resultado); // Ya calificó
    }

    //TESTEO REQUERIMIENTO 2.1 
    @Test
    public void testListarSalasOK() {
        //Completar para primera entrega
        miSistema.registrarSala("Sala Aire", 80);
        miSistema.registrarSala("Sala Fuego", 150);
        miSistema.registrarSala("Sala Agua", 200);
        miSistema.registrarSala("Sala Tierra", 100);
        miSistema.registrarSala("Sala Elemento", 1); //CASO BORDE - CAPACIDAD 1 (tenía que ser mayor a 0)

        Retorno retorno = miSistema.listarSalas();
        assertEquals(retorno.ok().resultado, retorno.resultado);

        String esperado = "sala elemento-1#sala tierra-100#sala agua-200#sala fuego-150#sala aire-80#";
        assertEquals(esperado, retorno.valorString);
        miSistema.listarSalas();
    }

    //TESTEO REQUERIMIENTO 2.2 - OK
    @Test
    public void testListarEventosOK() {
        miSistema.registrarSala("Sala Aire", 220);

        LocalDate fecha1 = LocalDate.of(2025, 12, 15);
        miSistema.registrarEvento("AAQ23", "Noche de gala", 100, fecha1);

        LocalDate fecha2 = LocalDate.of(2024, 12, 15);
        miSistema.registrarEvento("AZD456", "Tango feliz", 150, fecha2);

        LocalDate fecha3 = LocalDate.of(2023, 12, 15);
        miSistema.registrarEvento("AZK765", "Lectura", 200, fecha3);

        Retorno retorno = miSistema.listarEventos();
        System.out.println("Valor retornado: " + retorno.valorString);
        assertEquals(Retorno.ok().resultado, retorno.resultado);

        String esperado = "AAQ23-Noche de gala-sala aire-220-100-0#AZD456-Tango feliz-sala aire-220-150-0#AZK765-Lectura-sala aire-220-200-0#";
        assertEquals(esperado, retorno.valorString);

    }

    //TESTEO REQUERIMIENTO 2.3 
    @Test
    public void testListarClientes() {
        //Completar para primera entrega 

        miSistema.registrarCliente("45678913", "Julio Cesar");
        miSistema.registrarCliente("35678982", "Marco Aurelio");
        miSistema.registrarCliente("15678965", "Alejandro Magno");
        miSistema.registrarCliente("55678956", "Pompeyo Magno");
        miSistema.registrarCliente("49267892", "Escipion El Africano");

        Retorno retorno = miSistema.listarClientes();
        assertEquals(retorno.ok().resultado, retorno.resultado);
        String esperado = "15678965-Alejandro Magno#35678982-Marco Aurelio#45678913-Julio Cesar#49267892-Escipion El Africano#55678956-Pompeyo Magno#";
        assertEquals(esperado, retorno.valorString);
    }

    //TESTEO REQUERIMIENTO 2.4 - OK
    @Test
    public void testEsSalaOptimaOK() {
        String[][] vistaSala = {
            {"#", "#", "#", "#", "#", "#", "#"},
            {"#", "#", "X", "X", "X", "X", "#"},
            {"#", "O", "O", "X", "X", "X", "#"},
            {"#", "O", "O", "O", "O", "X", "#"},
            {"#", "O", "O", "X", "O", "O", "#"},
            {"#", "O", "O", "O", "O", "O", "#"},
            {"#", "X", "X", "O", "O", "O", "O"},
            {"#", "X", "X", "O", "O", "O", "X"},
            {"#", "X", "X", "O", "X", "X", "#"},
            {"#", "X", "X", "O", "X", "X", "#"},
            {"#", "#", "#", "O", "#", "#", "#"},
            {"#", "#", "#", "O", "#", "#", "#"}
        };

        Retorno ret = miSistema.esSalaOptima(vistaSala);
        assertEquals(Retorno.Resultado.OK, ret.resultado);
        assertEquals("Es optimo", ret.valorString);
    }

    //TESTEO REQUERIMIENTO 2.5 -> OK
    @Test
    public void testListarClientesDeEventoOK() {
        miSistema.registrarCliente("35679992", "Ramiro Perez");
        miSistema.registrarCliente("45678992", "Micaela Ferrez");
        miSistema.registrarCliente("11111111", "Juana Ferrez");
        miSistema.registrarCliente("88888888", "Maria Gomez"); // No compra nada
        miSistema.registrarCliente("77777777", "Pedro Perez");
        miSistema.registrarSala("Sala Principal", 100);
        miSistema.registrarEvento("EV100", "Concierto", 100, LocalDate.of(2025, 8, 20));
        // Clientes compran entradas
        miSistema.comprarEntrada("11111111", "EV100");
        miSistema.comprarEntrada("88888888", "EV100");
        miSistema.comprarEntrada("35679992", "EV100");
        miSistema.comprarEntrada("45678992", "EV100");
        miSistema.comprarEntrada("77777777", "EV100");
        //hasta aca me asegure que los agrego al evento en la lista clientesEnEvento.
        Retorno retorno = miSistema.listarClientesDeEvento("EV100", 3); //Me devuelve solo 2
        assertEquals(Retorno.ok().resultado, retorno.resultado);
        // Se esperan los últimos 3 compradores: Juana, Ramiro (2da vez), Pedro
        String esperado = "77777777-Pedro Perez#45678992-Micaela Ferrez#35679992-Ramiro Perez#";
        assertEquals(esperado, retorno.valorString);
    }

    //TESTEO REQUERIMIENTO 2.5 ERROR 1: EVENTO NO EXISTE.
    @Test
    public void testListarClientesDeEventoERROR1() {
        miSistema.registrarCliente("12345678", "Natalia");
        miSistema.registrarCliente("87654321", "Carlos");
        miSistema.registrarSala("Sala Principal", 100);
        miSistema.registrarEvento("EV100", "Concierto", 100, LocalDate.of(2025, 8, 20));
        // Clientes compran entradas
        miSistema.comprarEntrada("12345678", "E001");
        Retorno retorno = miSistema.listarClientesDeEvento("EV108", 3);
        assertEquals(Retorno.error1().resultado, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 2.6 -> OK
    @Test
    public void testListarEsperaEventoOK() {
        // Crear salas y clientes
        miSistema.registrarSala("Sala Principal", 100);
        miSistema.registrarCliente("11111111", "Ana");
        miSistema.registrarCliente("22222222", "Luis");
        miSistema.registrarCliente("33333333", "Carlos");

        // Registrar evento
        LocalDate fecha = LocalDate.of(2025, 5, 20);
        miSistema.registrarEvento("EVT100", "Reunion Privada", 2, fecha);
        miSistema.comprarEntrada("11111111", "EVT100");
        miSistema.comprarEntrada("22222222", "EVT100");
        miSistema.comprarEntrada("33333333", "EVT100");

        // Obtener el evento para manipular la lista de espera
        miSistema.listarEsperaEvento();

        // Llamar al método y validar retorno
        Retorno retorno = miSistema.listarEsperaEvento();
        assertEquals(Retorno.Resultado.OK, retorno.resultado);
    }

    //TESTEO REQUERIMIENTO 2.7
    @Test
    public void testDeshacerUltimasComprasOK() {
        // Registrar clientes
        miSistema.registrarCliente("11111111", "Juana Ferrez");
        miSistema.registrarCliente("22222222", "Pedro Perez");
        miSistema.registrarCliente("33333333", "Maria Gomez");

        // Registrar sala y evento
        miSistema.registrarSala("Sala Principal", 100);
        miSistema.registrarEvento("EV100", "Concierto", 100, LocalDate.of(2025, 8, 20));

        // Realizar compras
        miSistema.comprarEntrada("22222222", "EV100"); // Pedro
        miSistema.comprarEntrada("11111111", "EV100"); // Juana
        miSistema.comprarEntrada("33333333", "EV100"); // Maria

        // Deshacer las últimas 2 compras globales (Pedro y Maria)
        Retorno retorno = miSistema.deshacerUtimasCompras(2);
        assertEquals("33333333-Maria Gomez#11111111-Juana Ferrez#", retorno.valorString);
    }

    //TESTEO REQUERIMIENTO 2.8 - OK
    @Test
    public void testEventoMejorPuntuadoOK() {

        miSistema.registrarSala("Sala Baile", 200);
        LocalDate fecha1 = LocalDate.of(2025, 3, 15);
        LocalDate fecha2 = LocalDate.of(2025, 3, 16);
        LocalDate fecha3 = LocalDate.of(2025, 3, 17);

        // Registrar clientes
        miSistema.registrarCliente("23454312", "Juan");
        miSistema.registrarCliente("45666666", "Pedro");
        miSistema.registrarCliente("78966666", "Maria");

        // Registrar eventos
        miSistema.registrarEvento("EVT1", "Evento 1", 60, fecha1);
        miSistema.registrarEvento("EVT2", "Evento 2", 60, fecha2);
        miSistema.registrarEvento("EVT3", "Evento 3", 60, fecha3);

        // Calificar eventos
        miSistema.calificarEvento("234543123", "EVT1", 9, "Muy bueno");
        miSistema.calificarEvento("45666666", "EVT1", 9, "Excelente");

        miSistema.calificarEvento("23454312", "EVT2", 10, "Perfecto");
        miSistema.calificarEvento("45666666", "EVT2", 8, "Bueno");

        miSistema.calificarEvento("78966666", "EVT3", 9, "Muy bueno");

        // EVT1 tiene promedio 9
        // EVT2 tiene promedio 9 (10+8 / 2)
        // EVT3 tiene promedio 9 (una sola calificación)
        Retorno retorno = miSistema.eventoMejorPuntuado();
        assertEquals(Retorno.Resultado.OK, retorno.resultado);

        // Los tres tienen el mismo puntaje, se deben mostrar todos separados por #
        // según el enunciado: ordenados por código → EVT1-EVT2-EVT3
        String esperado = "EVT1-9.0#EVT2-9.0#EVT3-9.0";
        assertEquals(esperado, retorno.valorString);
    }

    //TESTEO REQUERIMIENTO 2.9
    @Test
    public void testComprasDeClienteOK() {

        miSistema.registrarSala("Sala Astronomia", 200);
        LocalDate fecha1 = LocalDate.of(2025, 3, 15);
        LocalDate fecha2 = LocalDate.of(2025, 3, 16);
        miSistema.registrarCliente("11111111", "María");
        miSistema.registrarEvento("EVT1", "Fiesta", 5, fecha1);
        miSistema.registrarEvento("EVT2", "Teatro", 5, fecha2);
        miSistema.comprarEntrada("11111111", "EVT1");
        miSistema.comprarEntrada("11111111", "EVT2");

        Retorno retorno = miSistema.comprasDeCliente("11111111");
        String esperado = "EVT1-N#EVT2-N#";
        assertEquals(esperado, retorno.valorString);

    }

    //TESTEO REQUERIMIENTO 2.10 - OK
    @Test
    public void testComprasPorDiaOK() {
        miSistema.registrarSala("Sala Astronomia", 200);
        miSistema.registrarCliente("11111111", "María");
        miSistema.registrarCliente("22222222", "Juan");
        miSistema.registrarCliente("33333333", "Juana");
        miSistema.registrarCliente("44444444", "Pepe");
        miSistema.registrarCliente("55555555", "Roberta");
        miSistema.registrarCliente("77777777", "Gregorio");

        // Fechas del mes 4 (abril)
        LocalDate fecha1 = LocalDate.of(2025, 4, 15);
        LocalDate fecha2 = LocalDate.of(2025, 4, 5);
        LocalDate fecha3 = LocalDate.of(2025, 4, 20);
        LocalDate fecha4 = LocalDate.of(2025, 4, 10);

        // Fechas del mes 6 (junio) para cambiar el mes
        LocalDate fecha5 = LocalDate.of(2025, 6, 15);
        LocalDate fecha6 = LocalDate.of(2025, 6, 5);
        LocalDate fecha7 = LocalDate.of(2025, 6, 20);

        // Fechas del mes 12 (diciembre) para casos borde
        LocalDate fecha8 = LocalDate.of(2026, 1, 1);
        LocalDate fecha9 = LocalDate.of(2025, 12, 31);

        // Registrar eventos
        miSistema.registrarEvento("EVT1", "Fiesta", 50, fecha1);
        miSistema.registrarEvento("EVT2", "Teatro", 50, fecha2);
        miSistema.registrarEvento("EVT3", "Concierto", 50, fecha3);
        miSistema.registrarEvento("EVT4", "Charla", 50, fecha4);
        miSistema.registrarEvento("EVT5", "Fiesta", 50, fecha5);
        miSistema.registrarEvento("EVT6", "Teatro", 50, fecha6);
        miSistema.registrarEvento("EVT7", "Concierto", 50, fecha7);
        miSistema.registrarEvento("EVT8", "Charla", 50, fecha8);
        miSistema.registrarEvento("EVT9", "Charla", 50, fecha9);

        // Compras en diferentes días para diferentes eventos
        miSistema.comprarEntrada("11111111", "EVT1");
        miSistema.comprarEntrada("22222222", "EVT1");
        miSistema.comprarEntrada("33333333", "EVT1");
        miSistema.comprarEntrada("33333333", "EVT2");
        miSistema.comprarEntrada("44444444", "EVT3");
        miSistema.comprarEntrada("55555555", "EVT2");
        miSistema.comprarEntrada("77777777", "EVT4");
        miSistema.comprarEntrada("11111111", "EVT5");
        miSistema.comprarEntrada("22222222", "EVT5");
        miSistema.comprarEntrada("33333333", "EVT6");
        miSistema.comprarEntrada("33333333", "EVT7");
        miSistema.comprarEntrada("44444444", "EVT8");
        miSistema.comprarEntrada("55555555", "EVT9");
        miSistema.comprarEntrada("77777777", "EVT10");

        // Test
        Retorno retorno = miSistema.comprasXDia(4); // mes Abril
        String esperado1 = "5-2#10-1#15-3#20-1#";
        assertEquals(esperado1, retorno.valorString);

        Retorno retornoJunio = miSistema.comprasXDia(6);
        String esperado2 = "5-1#15-2#20-1#";
        assertEquals(esperado2, retornoJunio.valorString);

        Retorno retornoDiciembre = miSistema.comprasXDia(12);
        String esperado3 = "31-1#";
        assertEquals(esperado3, retornoDiciembre.valorString);

        Retorno retornoEnero2026 = miSistema.comprasXDia(1);
        String esperado4 = "1-1#";
        assertEquals(esperado4, retornoEnero2026.valorString);
    }

    //TESTEO REQUERIMIENTO 2.10 - ERROR1
    @Test
    public void testComprasPorDiaERROR1() {
        miSistema.registrarSala("Sala Astronomia", 200);
        miSistema.registrarCliente("11111111", "María");
        miSistema.registrarCliente("22222222", "Juan");

        // Fechas del mes 4 (abril)
        LocalDate fecha1 = LocalDate.of(2025, 4, 15);

        // Registrar eventos
        miSistema.registrarEvento("EVT1", "Fiesta", 50, fecha1);

        // Compras en diferentes días para diferentes eventos
        miSistema.comprarEntrada("11111111", "EVT1");

        Retorno retorno1 = miSistema.comprasXDia(0);
        assertEquals(Retorno.error1().resultado, retorno1.resultado);

        Retorno retorno2 = miSistema.comprasXDia(13);
        assertEquals(Retorno.error1().resultado, retorno2.resultado);
    }
}
