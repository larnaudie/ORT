/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.clases;

import sistema.tads.Lista;
import java.time.LocalDate;

/**
 *
 * @author Dell
 */
public class Entrada implements Comparable<Entrada> {

    private Evento codigoEvento;
    private Cliente cliente;
    private LocalDate fechaCompra;
    private String estado;

    public Evento getCodigoEvento() {
        return codigoEvento;
    }

    public void setCodigoEvento(Evento codigoEvento) {
        this.codigoEvento = codigoEvento;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public LocalDate getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(LocalDate fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Entrada(Evento codigoEvento, Cliente cliente, LocalDate fechaCompra, String estado) {
        this.codigoEvento = codigoEvento;
        this.cliente = cliente;
        this.fechaCompra = fechaCompra;
        this.estado = estado;
    }

    public Entrada(Evento codigoEvento, Cliente cliente) {
        this.codigoEvento = codigoEvento;
        this.cliente = cliente;
    }

    @Override
    public int compareTo(Entrada otro) {
        // Primero por código de evento
        int cmp = this.codigoEvento.compareTo(otro.codigoEvento);
        if (cmp != 0) {
            return cmp;
        }
        // Si empatan, por cédula
        return this.cliente.compareTo(otro.cliente);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Entrada otra = (Entrada) obj;
        return this.getCliente().equals(otra.getCliente())
                && this.getSoloCodigoEvento().equals(otra.getSoloCodigoEvento());
    }

    public String getSoloCodigoEvento() {
        return this.getCodigoEvento().getCodigo();
    }

    public int getMesFechaCompra() {
        return this.fechaCompra.getMonthValue();
    }

    public int getDiaFechaCompra() {
        return this.fechaCompra.getDayOfMonth();
    }
}
