/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.clases;

import sistema.tads.Lista;
import sistema.tads.Cola;

import java.time.LocalDate;

/**
 *
 * @author pablo
 */
public class Evento implements Comparable<Evento> {

    private String codigo;
    private String descripcion;
    private int aforoNecesario;
    private LocalDate fecha;
    private Sala salaAsignada;
    private int cantidadEntradasDisponibles;
    private int cantidadEntradasVendidas;
    private Lista<Cliente> clientesEnEvento;
    private Cola<Cliente> listaDeEspera;
    private Lista<String> cedulasCalificadas;
    private Lista<Integer> puntajes;
    private Lista<String> comentarios;
    
    public Lista<String> getCedulasCalificadas() {
        return cedulasCalificadas;
    }

    public void setCedulasCalificadas(Lista<String> cedulasCalificadas) {
        this.cedulasCalificadas = cedulasCalificadas;
    }

    public Lista<Integer> getPuntajes() {
        return puntajes;
    }

    public void setPuntajes(Lista<Integer> puntajes) {
        this.puntajes = puntajes;
    }

    public Lista<String> getComentarios() {
        return comentarios;
    }

    public void setComentarios(Lista<String> comentarios) {
        this.comentarios = comentarios;
    }
    
    public Lista<Cliente> getClientesEnEvento() {
        return clientesEnEvento;
    }

    public void setClientesEnEvento(Lista<Cliente> clientesEnEvento) {
        this.clientesEnEvento = clientesEnEvento;
    }

    public Cola<Cliente> getListaDeEspera() {
        return listaDeEspera;
    }

    public void setListaDeEspera(Cola<Cliente> listaDeEspera) {
        this.listaDeEspera = listaDeEspera;
    }

    public int getCantidadEntradasDisponibles() {
        return cantidadEntradasDisponibles;
    }

    public void setCantidadEntradasDisponibles(int cantidadEntradasDisponibles) {
        this.cantidadEntradasDisponibles = cantidadEntradasDisponibles;
    }

    public int getCantidadEntradasVendidas() {
        return cantidadEntradasVendidas;
    }

    public void setCantidadEntradasVendidas(int cantidasEntradasVendidas) {
        this.cantidadEntradasVendidas = cantidasEntradasVendidas;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getAforoNecesario() {
        return aforoNecesario;
    }

    public void setAforoNecesario(int aforoNecesario) {
        this.aforoNecesario = aforoNecesario;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Sala getSalaAsignada() {
        return salaAsignada;
    }

    public void setSalaAsignada(Sala salaAsignada) {
        this.salaAsignada = salaAsignada;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Evento)) {
            return false;
        }
        if (obj == null) {
            return false;
        }

        return this.codigo.equals(((Evento) obj).getCodigo());
    }

    @Override
    public int compareTo(Evento otro) {
        return this.codigo.compareTo(otro.codigo);
    }

    @Override
    public String toString() {
        return this.getCodigo() + "-" + this.getDescripcion() + "-" + this.getSalaAsignada() + "-" + this.getCantidadEntradasDisponibles() + "-" + this.getCantidadEntradasVendidas();
    }

public Evento(String codigo, String descripcion, int aforoNecesario, LocalDate fecha) {
    this.codigo = codigo;
    this.descripcion = descripcion;
    this.aforoNecesario = aforoNecesario;
    this.fecha = fecha;
    
    // Inicializaciones necesarias
    this.clientesEnEvento = new Lista<>();
    this.listaDeEspera = new Cola<>();
    this.cedulasCalificadas = new Lista<>();
    this.puntajes = new Lista<>();
    this.comentarios = new Lista<>();
}
    public Evento() {

    }

    public Evento(String codigo) {
        this.codigo = codigo;
    }

    //-------------- FUNCIONES AGREGADAS --------------//
    public void asignarSala(Sala sala) {
        this.salaAsignada = sala;
    }

    public void agregarClienteAEvento(Cliente cliente) {
        this.clientesEnEvento.agregarInicio(cliente);
    }
    /*
    public Lista<String> reotrnarCedulas() {
         Lista<String> resultado = new Lista<>();
        for(int i=0; i < clientesEnEvento.largoLista(); i++){
            resultado += 
        }
        return resultado;
    }*/

    public void agregarAListaEspera(Cliente cedula) {
        this.listaDeEspera.encolar(cedula);
    }

    public void desasignarSala() {
        this.salaAsignada = null;
    }

    public Lista<Cliente> clientesEsperaOrdenadosPorCedula() {
        //Creamos una copia para no perjudicar la orignial
        Cola<Cliente> copiaDeLaListaDeEspera = listaDeEspera;
        //La listaOrdenada va a almacenar los elementos ordenados
        Lista<Cliente> listaOrdenada = new Lista<>();

        while (!copiaDeLaListaDeEspera.estaVacia()) {
            listaOrdenada.insertarOrdenado(copiaDeLaListaDeEspera.primero());
            copiaDeLaListaDeEspera.desencolar();
        }

        return listaOrdenada;
    }
    
    public void agregarCalificacion(String cedula, int puntaje, String comentario) {
        if (cedulasCalificadas == null) {
            cedulasCalificadas = new Lista<>();
            puntajes = new Lista<>();
            comentarios = new Lista<>();
        }
        cedulasCalificadas.agregarFinal(cedula);
        puntajes.agregarFinal(puntaje);
        comentarios.agregarFinal(comentario);
    }
    
    public void quitarClienteAEvento (Cliente cliente) {
        this.clientesEnEvento.borrarElemento(cliente);
    }
}
