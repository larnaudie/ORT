// CONFIGURACION

$(document).ready(inicio);

function inicio(){
    cargarUsuarios();
    datosPrueba();
    ocultarTodo();
    $("#iniciarSesion").show();
    // Asignacion de eventos
    $("#mnuRegistrarPelicula").click(mostrarFormRegistroPelicula);
    $("#archivo").change(mostrarImagen);
    $("#btnRegistrarPelicula").click(registrarPelicula);
    $("#iniciarSesion").click(mostrarFormLogin)
    $("#cerrarSesion").click(cerrarSesion)
    $("#btnIniciarSesion").click(iniciarSesion);
    $("#mnuListadoPeliculas").click(mostrarFormListadoPeliculas);
    $("#mnuRegistrarVoto").click(mostrarFormRegistrarVoto);
    $("#btnRegistrarVoto").click(registrarVoto);
}
 
function ocultarTodo(){
    $("#navPrincipal").hide()
    $("#iniciarSesion").hide();
    $("#cerrarSesion").hide();
    $("#login").hide();
    $("#registrarPelicula").hide();
    $("#registrarVoto").hide();
    $("#catalogo").hide();
}

function cargarUsuarios(){
    listaUsuarios = [
        {usuario:"usuario1",clave:"123"},
        {usuario:"usuario2",clave:"321"},
        {usuario:"usuario3",clave:"111"}        
    ];
    
    /*
    Otra forma:
    listaUsuarios.push({usuario:"usuario1",clave:"123"});
    listaUsuarios.push({usuario:"usuario2",clave:"321"});
    listaUsuarios.push({usuario:"usuario3",clave:"111"});
    
    Otra forma:
    var unUsusario = {usuario:"usuario1",clave:"123"};
    listaUsuarios.push(unUsuario);
    unUusario = {usuario:"usuario2",clave:"321"};
    listaUsuarios.push(unUsuario);
    unUusario = {usuario:"usuario3",clave:"111"}; 
    listaUsuarios.push(unUsuario);
     * **/
    
    
}

function datosPrueba(){
  agregarPelicula("Coco","Cualquier cosa",2018,"peli1.jpg");
  agregarPelicula("PArtido","Cualquier cosa",2016,"peli2.jpg");
  agregarPelicula("Mundial","Cualquier cosa",2012,"peli3.jpg");
}

function mostrarFormRegistrarVoto(){
    ocultarTodo();
    $("#registrarVoto").show(); 
    $("#navPrincipal").show(); 
     $("#cerrarSesion").show(); 
    cargarListaPeliculasParaVotar();

}
function cargarListaPeliculasParaVotar(){
    $("#lstTitulo").html(""); // Borro el contenido del select
    // Agrego los option sacando los datos de la lista de peliculas
    for (i=0;i<listaPeliculas.length;i++){
        var unaPelicula = listaPeliculas[i];
        $("#lstTitulo").append("<option value='"+unaPelicula.titulo+"'>"+unaPelicula.titulo+"</option>");
    }
}

function mostrarFormRegistroPelicula(){
    ocultarTodo();
   $("#registrarPelicula").show(); 
   $("#navPrincipal").show(); 
   $("#cerrarSesion").show(); 
}

function mostrarFormListadoPeliculas() {
   ocultarTodo();
   $("#catalogo").show(); 
   $("#navPrincipal").show(); 
   $("#cerrarSesion").show();
   listarPeliculas();
    
}

function mostrarFormLogin(){
   ocultarTodo();
   $("#login").show(); 
}

// LISTAS GLOBALES

var listaPeliculas=new Array();

var listaVotos=new Array();

var listaUsuarios = new Array();

// VARIABLES GLOBALES

var usuarioLogeado;


// FUNCIONES DE INTERFAZ DE USUARIO

function cerrarSesion(){
    ocultarTodo();
    usuarioLogeado = "";
    $("#nomUsuario").html("");
    $("#iniciarSesion").show();
}

function registrarPelicula(){
    var titulo = $("#txtTitulo").val();
    var genero = $("#txtGenero").val();
    var año = parseInt($("#txtAño").val());
    var imagen = nombreArchivo($("#archivo").val());
    if (!existePelicula(titulo)){
        agregarPelicula(titulo,genero,año,imagen);
        $("#msjRegistroPelicula").html("Registro exitoso !");
        limpiarCamposFormRegistroPelicula();
    }
    else {
        $("#msjRegistroPelicula").html("La pelicula ya existe");
    }
    
    
}

function mostrarImagen(){
    var ruta = $("#archivo").val();
    if (ruta!=""){
        var imagen = nombreArchivo(ruta);
        $("#imgFicha").html("<img height='50' width='50' src='img/"+imagen+"' alt='portada'>")
    }
}


function nombreArchivo(ruta){
    var pos=ruta.length-1;
    var nombreArchivo="";
    var seguir = true;
    while (pos>=0 && seguir){ // Recorro hasta que seguir sea false
 
        if (ruta[pos]=="\\"){ //Cuando encuentro la primera barra
            seguir = false; // indico que debe parar la iteracion.
        }
        if (seguir){
         nombreArchivo=ruta[pos]+nombreArchivo; // Para que no quede el nombre invertido
        }
        pos--;
    }
    
    return nombreArchivo;
}

function iniciarSesion(){
    var usuario = $("#txtUsuario").val();
    var clave = $("#txtClave").val();
    if (existeUsuario(usuario,clave)){
        usuarioLogeado = usuario;
        $("#nomUsuario").html(" Bienvenido/a " + usuarioLogeado + " ");
        //Muestro el div que contiene el menu
        // Muestro la opcion de cerrar sesion
        ocultarTodo();
        $("#navPrincipal").show();
        $("#cerrarSesion").show();
        
    }
    else{
      $("#msjLogin").html("Usuario y/o clave incorrecta");  
    }
}



function limpiarCamposFormRegistroPelicula(){
    $("#txtTitulo").val("");
    $("#txtGenero").val("");
    $("#txtAño").val("");
    $("#archivo").val("");
    $("#imgFicha").html("");
}

function listarPeliculas(){
    $("#tablaPeliculas").html(""); //Limpio la tabla por si tenia algo antes
    $("#CantidadVotos").html("");
    $("#tablaPeliculas").append("<tr><td>Titulo</td><td>Genero</td><td>Año</td><td>Portada</td><td></td></tr>")
    listaPeliculas.sort(criterioPeliculasPorTitulo);
    
    for(i=0;i<listaPeliculas.length;i++){
        unaPelicula=listaPeliculas[i];
        $("#tablaPeliculas").append("<tr><td>"+unaPelicula.titulo+
                                    "</td><td>"+unaPelicula.genero+
                                    "</td><td>"+unaPelicula.año+
                                    "</td><td><img height='50' width='50' src='img/"+unaPelicula.imagen+"'alt='afiche'></td><td>"+
                                    "<input type='button' value='Contar Votos' id='"+i+"'></td><tr>")
        $("#"+i).click(seleccionTabla);
    }   
}

function seleccionTabla(){
    var botonSeleccionado = $(this); // Obtengo cual fue el boton de la lista que fue seleccionado  
    var idDelBotonSeleccionado = botonSeleccionado.prop("id"); // Obtengo el id del boton seleccionado
    var peliculaSel = listaPeliculas[idDelBotonSeleccionado]; //COn el id (que es la posicion en la lista) obtengo el objeto pelicula
    var cantidadVotos = contarVotos(peliculaSel.titulo); // Llamo a la funcion que cuenta los votos
    $("#CantidadVotos").html(peliculaSel.titulo+" fue votada "+cantidadVotos+" veces."); // Cargo el div de resultados (id CantidadVotos) con el dato.
 
}

function contarVotos(unTitulo){
    // HAgo un contador que arranca en 0 , recorro la 
    // lista de votos y cuando encuentro un voto cuyo titulo
    // sea el que me pasan por parametro le sumo 1 al contador
    var contador = 0;
    for (i=0;i<listaVotos.length;i++){
        if (listaVotos[i].titulo==unTitulo){ // Encontre un voto que me sirve
            contador++;
        }
    }
    return contador;
}


function registrarVoto(){
    var titulo = $("#lstTitulo").val();
    var valor = parseInt($("#txtValor").val());
    if (titulo!="" && !isNaN(valor)){
        agregarVoto(titulo,valor);
        $("#msjRegistroVoto").html("Registro exitoso !"); 
    }
    else {
        $("#msjRegistroVoto").html("Error: Faltan datos !");
    }
    
}




// FUNCIONES DE LOGICA DEL PROBLEMA

function criterioPeliculasPorAño(pelicula1,pelicula2){
    var resultado = 0;
    
    if (pelicula1.año < pelicula2.año){
        resultado = -1;
    }
    else {
        if (pelicula1.año > pelicula2.año){
            resultado = 1;
        }
  
    }
    return resultado;
}

function criterioPeliculasPorTitulo(pelicula1,pelicula2){
    var resultado = 0;
    
    if (pelicula1.titulo < pelicula2.titulo){
        resultado = -1;
    }
    else {
        if (pelicula1.titulo > pelicula2.titulo){
            resultado = 1;
        }
  
    }
    return resultado;
}


function existePelicula(unTitulo){
    var encontrada = false;
    var pos=0;
    while(pos<listaPeliculas.length && !encontrada){
        if(listaPeliculas[pos].titulo==unTitulo){
            encontrada = true;
        }
        pos++;
    }
    return encontrada;
}

function existeUsuario(unUsuario,unaClave){
    var encontrado = false;
    var pos=0;
    while(pos<listaUsuarios.length && !encontrado){
        if(listaUsuarios[pos].usuario==unUsuario && listaUsuarios[pos].clave==unaClave){
            encontrado = true;
        }
        pos++;
    }
    return encontrado;
}

function agregarPelicula(unTitulo,unGenero,unAño,unaImagen){
    if (!existePelicula(unTitulo)){
        var unaPelicula = {titulo: unTitulo, genero: unGenero, año:unAño,imagen:unaImagen};
        listaPeliculas.push(unaPelicula);
    }
}
function agregarVoto(unTitulo,unValor){
    var unVoto = {titulo: unTitulo, valor: unValor};
    listaVotos.push(unVoto);
}


