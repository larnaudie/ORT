package sistemaAutogestion;

import sistema.clases.Cliente;
import sistema.clases.Evento;
import sistema.clases.Sala;
import sistema.clases.Entrada;
import sistema.tads.Lista;
import java.time.LocalDate;

public class Sistema implements IObligatorio {

    private Lista<Sala> listaDeSalas;
    private Lista<Evento> listaDeEventos;
    private Lista<Cliente> listaDeClientes;
    private Lista<Entrada> listaDeEntradas;

    //-------------- REQUERIMIENTO 1.1 --------------//
    @Override
    public Retorno crearSistemaDeGestion() {
        listaDeSalas = new Lista();
        listaDeEventos = new Lista();
        listaDeClientes = new Lista();
        listaDeEntradas = new Lista();
        return Retorno.ok();
    }

    //-------------- REQUERIMIENTO 1.3 --------------//
    @Override
    public Retorno eliminarSala(String nombre) {

        String nombreEstandarizado = estandarizarNombre(nombre);
        Sala salaConNombre = null;

        for (int i = 0; i < listaDeSalas.largoLista(); i++) {
            Sala sala = listaDeSalas.obtenerElementoInt(i);
            if (sala.getNombre().equals(nombreEstandarizado)) {
                salaConNombre = sala;
                break;
            }
        }
        if (salaConNombre == null) {
            return (Retorno.error1()); //En letra: "sala no existe"
        } else {
            listaDeSalas.borrarElemento(salaConNombre);
        }
        return (Retorno.ok());
    }

    //-------------- REQUERIMIENTO 1.2 --------------//
    @Override
    public Retorno registrarSala(String nombre, int capacidad) {

        if (capacidad <= 0) {
            return (Retorno.error2()); // Según letra: capacidad es menor o igual a 0
        }

        String nombreEstandarizado = estandarizarNombre(nombre);

        //Primero se hace una instancia de Sala con el nombre recibido
        Sala sBusq = new Sala();
        sBusq.setNombre(nombreEstandarizado);

        //luego buscamos que ya no exista este registro
        Sala salaReal = listaDeSalas.buscarElemento(sBusq);
        if (salaReal != null) {
            return (Retorno.error1()); //En letra: "ya existe una sala con ese nombre"
        }

        sBusq.setCapacidad(capacidad);

        //se agrega al inicio (por requerimiento 2.1 para que quede orden inverso al registro) y se retorna Ok (solicitado en letra)
        listaDeSalas.agregarInicio(sBusq);
        return (Retorno.ok()); //se pudo registrar
    }

    //-------------- REQUERIMIENTO 1.4 --------------//
    @Override
    public Retorno registrarEvento(String codigo, String descripcion, int aforoNecesario, LocalDate fecha) {

        Evento nuevoEvento = new Evento(codigo, descripcion, aforoNecesario, fecha);
        if (listaDeEventos.buscarElemento(nuevoEvento) != null) {
            return Retorno.error1(); //por letra: ya existe evento con ese código
        }

        if (aforoNecesario <= 0) {
            return Retorno.error2(); //por letra:aforo necesario debe ser mayor a 0
        }

        Sala salaDisponible = null;

        for (int i = 0; i < listaDeSalas.largoLista(); i++) {

            Sala sala = listaDeSalas.obtenerElementoInt(i);

            if (sala.getCapacidad() >= aforoNecesario && sala.estaDisponible(fecha)) {
                salaDisponible = sala;
                break;
            }
        }

        if (salaDisponible == null) {
            return (Retorno.error3()); //por letra: no hay salas disponibles para esa fecha con aforo suficiente
        }
        nuevoEvento.asignarSala(salaDisponible);    // Asignar la sala
        salaDisponible.agendarEvento(fecha); //Reservar esa fecha
        salaDisponible.agregarEvento(nuevoEvento); //guardar evento en su sala
        nuevoEvento.setCantidadEntradasDisponibles(aforoNecesario);
        nuevoEvento.setCantidadEntradasVendidas(0);
        listaDeEventos.insertarOrdenado(nuevoEvento); //insertar por codigo ordenado en la lista de eventos del sistema

        return Retorno.ok();
    }

    //-------------- REQUERIMIENTO 1.5 --------------//
    //primera entrega
    @Override
    public Retorno registrarCliente(String cedula, String nombre) {

        String nombreConveritdo = letrasCapitalesEnMayuscula(nombre);
        //Primero se hace una instancia de Cliente con la CI recibida
        Cliente cBusq = new Cliente(cedula, nombreConveritdo);

        if (!cBusq.esCedulaValida()) {
            return Retorno.error1(); // Cédula no válida. Por letra: no tiene exactamento 8 digitos. Además le agregamos el chequeo de que sea numérico
        }

        //luego buscamos que ya no exista este registro
        Cliente clienteReal = listaDeClientes.buscarElemento(cBusq);
        if (clienteReal != null) {
            return (Retorno.error2()); //En letra: "ya existe cliente registrado con esa CI"
        }
        //se iserta ordenado por requerimiento de letra (Listar en orden CI)
        listaDeClientes.insertarOrdenado(cBusq);
        return (Retorno.ok()); //se pudo registrar
    }

    //-------------- REQUERIMIENTO 1.6 --------------//
    @Override
    public Retorno comprarEntrada(String cedula, String codigoEvento) {
        //VALIDACIÓN 1: que exista el cliente
        //instancia cliente con ci recibida.
        Cliente cBusq = new Cliente(cedula);
        //luego buscamos que ya no exista este registro
        Cliente cliente = listaDeClientes.buscarElemento(cBusq);
        if (cliente == null) {
            return (Retorno.error1()); //En letra: "Cliente no existe"
        }
        //VALIDACIÓN 2: que exista el evento
        //repetimos operación anterior para ver si evento existe
        Evento eBusq = new Evento(codigoEvento);
        //luego buscamos que ya no exista este registro
        Evento evento = listaDeEventos.buscarElemento(eBusq);
        if (evento == null) {
            return (Retorno.error2()); //En letra: "Evento no existe"
        }
        if (evento.getCantidadEntradasDisponibles() > 0) {
            evento.setCantidadEntradasDisponibles(evento.getCantidadEntradasDisponibles() - 1);
            evento.setCantidadEntradasVendidas(evento.getCantidadEntradasVendidas() + 1);
            //agregar cliente al evento
            evento.agregarClienteAEvento(cliente);
            //agregar evento al cliente
            cliente.agregarEventoACliente(evento);

            Entrada entradaNueva = new Entrada(evento, cliente, evento.getFecha(), "N");

            listaDeEntradas.agregarInicio(entradaNueva);

            return (Retorno.ok()); //si pudo comprar la entrada
        } else {
            evento.agregarAListaEspera(cliente);
            return (Retorno.ok()); //se agrego a lista de espera
        }
    }

    //-------------- REQUERIMIENTO 1.7 --------------//
    @Override
    public Retorno eliminarEvento(String codigo) {
        Evento eBusq = new Evento(codigo);
        //luego buscamos que ya no exista este registro
        Evento evento = listaDeEventos.buscarElemento(eBusq);
        if (evento == null) {
            return (Retorno.error1()); //En letra: "Evento no existe"
        }
        if (evento.getCantidadEntradasVendidas() == 0) {
            listaDeEventos.borrarElemento(evento);
            return (Retorno.ok());
        } else {
            //borrar evento de la lista de sala
            evento.desasignarSala();
            //luego de liberar sala y devolver entrada puedo elimianar
            listaDeEventos.borrarElemento(evento);
            return (Retorno.error2()); //El evento tiene entradas vendidas
        }
    }

    //-------------- REQUERIMIENTO 1.8 --------------//
    @Override
    public Retorno devolverEntrada(String cedula, String codigo) {
        //VALIDACIÓN 1: que exista el cliente
        //instancia cliente con ci recibida.
        Cliente cBusq = new Cliente(cedula);
        //luego buscamos que ya no exista este registro
        Cliente cliente = listaDeClientes.buscarElemento(cBusq);
        if (cliente == null) {
            return (Retorno.error1()); //En letra: "Cliente no existe"
        }
        //VALIDACIÓN 2: que exista el evento
        //repetimos operación anterior para ver si evento existe
        Evento eBusq = new Evento(codigo);
        //luego buscamos que ya no exista este registro
        Evento evento = listaDeEventos.buscarElemento(eBusq);
        if (evento == null) {
            return (Retorno.error2()); //En letra: "Evento no existe"
        }

        //Buscamos la entrada
        cliente.quitarEventoACliente(evento);
        Entrada entrada = new Entrada(evento, cliente);
        Entrada entradaEncontrada = listaDeEntradas.buscarElemento(entrada);
        listaDeEntradas.borrarElemento(entradaEncontrada);

        if (evento.getListaDeEspera() != null && !evento.getListaDeEspera().estaVacia()) {
            Cliente nuevoCli = evento.getListaDeEspera().primero();
            evento.getListaDeEspera().desencolar();
            nuevoCli.agregarEventoACliente(evento);

            Entrada nuevaEntrada = new Entrada(evento, nuevoCli);
            listaDeEntradas.agregarInicio(nuevaEntrada);
        }
        return (Retorno.ok());
    }

    //-------------- REQUERIMIENTO 1.9 --------------//
    @Override
    public Retorno calificarEvento(String cedula, String codigoEvento, int puntaje, String comentario) {
        //VALIDACIÓN 1: que exista el cliente
        //instancia cliente con ci recibida.
        Cliente cBusq = new Cliente(cedula);

        //luego buscamos que ya no exista este registro
        Cliente cliente = listaDeClientes.buscarElemento(cBusq);
        if (cliente == null) {
            return (Retorno.error1()); //En letra: "Cliente no existe"
        }

        //VALIDACIÓN 2: que exista el evento
        //repetimos operación anterior para ver si evento existe
        Evento eBusq = new Evento(codigoEvento);

        //luego buscamos que ya no exista este registro
        Evento evento = listaDeEventos.buscarElemento(eBusq);
        if (evento == null) {
            return (Retorno.error2()); //En letra: "Evento no existe"
        }
        //Verificar rango del puntaje
        if (puntaje < 1 || puntaje > 10) {
            return Retorno.error3(); // Puntaje inválido
        }

        //Verificar si ya lo calificó
        if (cliente.yaCalifico(codigoEvento)) {
            return Retorno.error4(); // Ya calificó el evento
        }

        //Registrar la calificación
        evento.agregarCalificacion(cliente.getCedula(), puntaje, comentario);
        cliente.registrarCalificacion(codigoEvento);

        return Retorno.ok();
    }

    //-------------- REQUERIMIENTO 2.1 --------------//
    @Override
    public Retorno listarSalas() {
        if (listaDeSalas.esVacia()) {
            Retorno ret = (Retorno.ok());
            ret.valorString = "No hay salas registradas.";
            return ret;
        }
        String reporte = listaDeSalas.mostrarString();

        Retorno ret = Retorno.ok();
        ret.valorString = reporte;
        return ret;
    }

    //-------------- REQUERIMIENTO 2.2 --------------//
    @Override
    public Retorno listarEventos() {
        if (listaDeEventos.esVacia()) {
            Retorno ret = (Retorno.ok());
            ret.valorString = "No hay eventos registrados.";
            return ret;
        }
        String reporte = listaDeEventos.mostrarString();
        Retorno ret = (Retorno.ok());
        ret.valorString = reporte;
        return ret;
    }

    //-------------- REQUERIMIENTO 2.3 --------------//
    @Override
    public Retorno listarClientes() {

        if (listaDeClientes.esVacia()) {
            Retorno ret = (Retorno.ok());
            ret.valorString = "No hay clientes registrados.";
            return ret;
        }
        String reporte = listaDeClientes.mostrarString();
        Retorno ret = (Retorno.ok());
        ret.valorString = reporte; //le mando el valor para atrás asi lo usa JUNIT
        return ret;
    }

    //-------------- REQUERIMIENTO 2.4 --------------//
    @Override
    public Retorno esSalaOptima(String[][] vistaSala) {

        if (vistaSala == null || vistaSala.length == 0 || vistaSala[0].length == 0) {
            Retorno ret = (Retorno.ok());
            ret.valorString = "No se ingresó por parametros valores validos";
            return ret;
        }

        int filas = vistaSala.length;
        int columnas = vistaSala[0].length;

        int columnasOptimas = 0;

        for (int col = 0; col < columnas; col++) {
            int maxOcupadosConsecutivos = 0;
            int actualesOcupados = 0;
            int asientosLibres = 0;

            for (int fila = 0; fila < filas; fila++) {
                String asiento = vistaSala[fila][col];

                if (asiento.equals("O")) {
                    actualesOcupados++;
                    maxOcupadosConsecutivos = Math.max(maxOcupadosConsecutivos, actualesOcupados);
                } else {
                    actualesOcupados = 0; // rompemos la secuencia
                }

                if (asiento.equals("X")) {
                    asientosLibres++;
                }
            }

            if (maxOcupadosConsecutivos > asientosLibres) {
                columnasOptimas++;
            }
        }

        if (columnasOptimas >= 2) {
            Retorno ret = (Retorno.ok());
            ret.valorString = "Es optimo";
            return ret;
        } else {
            Retorno ret = (Retorno.ok());
            ret.valorString = "No es optimo";
            return ret;
        }
    }

    //-------------- REQUERIMIENTO 2.5 --------------//
    @Override
    public Retorno listarClientesDeEvento(String codigo, int n) {
        String resultado = "";
        Evento eBusq = new Evento(codigo);
        //luego buscamos que ya no exista este registro
        Evento evento = listaDeEventos.buscarElemento(eBusq);
        if (evento == null) {
            return (Retorno.error1()); //En letra: "Evento no existe"
        }
        if (n < 1) {
            return (Retorno.error2());
        }

        if (evento.getClientesEnEvento().largoLista() < n) {
            resultado = evento.getClientesEnEvento().mostrarString();
        } else {
            resultado = evento.getClientesEnEvento().mostrarNCantidad(n);
        }
        Retorno ret = (Retorno.ok());
        ret.valorString = resultado;
        return ret;
    }

    //-------------- REQUERIMIENTO 2.6 --------------//
    @Override
    public Retorno listarEsperaEvento() {
        //Variable para guardar el resultado
        String resultado = "";
        //recorremos los eventos
        for (int i = 0; i < listaDeEventos.largoLista(); i++) {
            //creamos un evento actual que toma el indice del for para corroborar que tenga lista de espera
            Evento eventoAct = listaDeEventos.obtenerElementoInt(i);
            if (eventoAct.getListaDeEspera() != null) {
                //si no es nulo, creamos lista donde se guardan los clientes en espera por cedula
                Lista<Cliente> lista = eventoAct.clientesEsperaOrdenadosPorCedula();
                //Una vez que tenemos esta lista, se recorren los clientes ordenados
                for (int j = 0; j < lista.largoLista(); j++) {
                    //crea un cliente tipo cliente obtenido de la lista mientras que recorre los clientes en for
                    Cliente cliente = lista.obtenerElementoInt(j);
                    //ahora podemos ahcer cliente.getCedula y combinar los strings.
                    resultado += eventoAct.getCodigo() + "-" + cliente.getCedula() + "#";
                }
            }

        }
        return Retorno.ok();
    }

    //-------------- REQUERIMIENTO 2.7 --------------//
    /**
     * Descripción: Se deben deshacer las últimas n compras de entradas
     * realizadas (tomando en cuenta todos eventos), devolviendo las mismas a
     * sus respectivos eventos. Se deben mostrar las entradas, detallando:
     * código del evento, cédula de identidad del cliente (ordenado por código
     * de evento/cédula de cliente)
     *
     */
    @Override
    public Retorno deshacerUtimasCompras(int n) {
        String resultado = "";

        for (int i = 0; i < n; i++) {
            if (listaDeEntradas.largoLista() == 0) {
                break; // Por si no hay entradas
            }
            // Siempre obtener la última entrada comprada (índice 0)
            Entrada entrada = listaDeEntradas.obtenerElementoInt(0);
            Evento evento = entrada.getCodigoEvento();
            Cliente cliente = entrada.getCliente();

            // Usar el mismo método de devolución
            this.devolverEntrada(cliente.getCedula(), entrada.getSoloCodigoEvento());

            // Quitar cliente de evento (si devolverEntrada no lo hace ya)
            evento.quitarClienteAEvento(cliente);

            // Agregar al string de resultado
            resultado += cliente.toString() + "#";
        }

        Retorno ret = Retorno.ok();
        ret.valorString = resultado;
        return ret;
    }

    //-------------- REQUERIMIENTO 2.8 --------------//
    @Override
    public Retorno eventoMejorPuntuado() {

        double mejorPuntajePromedio = 0;
        String resultado = "";

        for (int i = 0; i < listaDeEventos.largoLista(); i++) {

            //en cada recorrida de la lista de eventos, selecciono un evento
            Evento eventoSeleccionado = listaDeEventos.obtenerElementoInt(i);
            //obtengo los puntajes de ese evento y los guardo en la lista puntajes. 
            Lista<Integer> puntajes = eventoSeleccionado.getPuntajes();

            //creo la variable sumaPuntajes para guardar en ella la sumatoria de los puntajes del evento seleccionado
            int sumaPuntajes = 0;
            //recorro la lista puntajes y en cada iteración sumo los puntajes. 
            for (int j = 0; j < puntajes.largoLista(); j++) {
                sumaPuntajes += puntajes.obtenerElementoInt(j);
            }

            //creo la variable promedio donde se guardará el promedio del evento seleccionado. El mismo se calcula dividiendo la suma de puntos del evento seleccionado por la cantidad de puntajes obtenidos
            double promedio = (double) sumaPuntajes / puntajes.largoLista();

            //si el promedio es mayor al mejor promedio, el mejor promedio será ahora el del promedio. El string resultado que se mostrará será el codigo del evento y el numero promedio.
            if (promedio > mejorPuntajePromedio) {
                mejorPuntajePromedio = promedio;
                resultado += eventoSeleccionado.getCodigo() + "-" + promedio;
            } else if (promedio == mejorPuntajePromedio) {
                //En el caso contrario, resultado será el codigo del evento + el promedio. 
                resultado += "#" + eventoSeleccionado.getCodigo() + "-" + promedio;
            }
        }
        //se devuelve el string solicitado. 
        Retorno ret = (Retorno.ok());
        ret.valorString = resultado;
        return ret;
    }

    //-------------- REQUERIMIENTO 2.9 --------------//    
    @Override
    public Retorno comprasDeCliente(String cedula) {

        // Verificar si el cliente existe
        Cliente cBusq = new Cliente(cedula);
        Cliente cliente = listaDeClientes.buscarElemento(cBusq);
        if (cliente == null) {
            return Retorno.error1(); // Cliente no existe
        }
        String resultadoMostrado = "";
        for (int i = listaDeEntradas.largoLista() - 1; i >= 0; i--) {
            Entrada entrada = listaDeEntradas.obtenerElementoInt(i);

            if (cliente.getCedula().equals(cedula)) {
                resultadoMostrado += entrada.getSoloCodigoEvento() + "-" + entrada.getEstado() + "#";
            }
        }
        Retorno ret = (Retorno.ok());
        ret.valorString = resultadoMostrado;
        return ret;
    }

    //-------------- REQUERIMIENTO 2.10 --------------//
    @Override
    public Retorno comprasXDia(int mes) {
        if (mes < 1 || mes > 12) {
            return Retorno.error1(); // o el código de error que uses para mes inválido
        }
        //Me va a interesar guardarme el string de la firma
        String resultado = "";
        //Quiero primero creo los dias para cada mes
        int[] diasDeLosMeses = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        //Luego guardarme cuantos dias tiene el mes por parametro
        int cantidadDias = 0;

        for (int i = 1; i < diasDeLosMeses.length; i++) {
            if (i == mes) {
                cantidadDias = diasDeLosMeses[i];
            }
        }
        //Conociendo el mes y la cantidad de dias del mes, recorro los dias y la listaDeEntradas
        for (int i = 1; i <= cantidadDias; i++) {
            int cantidadEntradasPorDia = 0;
            int diaActual = i;
            for (int j = 0; j < listaDeEntradas.largoLista(); j++) {
                Entrada entradaActual = listaDeEntradas.obtenerElementoInt(j);
                if (entradaActual.getDiaFechaCompra() == diaActual && entradaActual.getMesFechaCompra() == mes) {//
                    cantidadEntradasPorDia++;
                }
            }
            if (cantidadEntradasPorDia != 0) {
                resultado += diaActual + "-" + cantidadEntradasPorDia + "#";
            }

        }
        Retorno retorno = Retorno.ok();
        retorno.valorString = resultado;
        return retorno;
    }

    //------------------ FUNCIONES AGREGADAS ---------------------------//
    private String estandarizarNombre(String nombre) {
        return nombre.trim().toLowerCase().replaceAll("\\s+", " ");
    }

    public static String letrasCapitalesEnMayuscula(String texto) {
        if (texto == null || texto.isEmpty()) {
            return texto;
        }

        String[] palabras = texto.split(" ");
        String resultado = "";

        for (String palabra : palabras) {
            if (!palabra.isEmpty()) {
                String primeraLetra = palabra.substring(0, 1).toUpperCase();
                String resto = palabra.substring(1).toLowerCase(); // opcional
                resultado = resultado + primeraLetra + resto + " ";
            }
        }

        return resultado.trim();
    }

}
