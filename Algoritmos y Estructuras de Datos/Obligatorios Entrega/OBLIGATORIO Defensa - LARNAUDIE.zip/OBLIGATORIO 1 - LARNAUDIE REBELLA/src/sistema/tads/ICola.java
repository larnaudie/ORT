/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.tads;

/**
 *
 * @author Dell
 */
public interface ICola<T>{
    
    public void encolar(T dato);
    public T desencolar();
    public T primero();
    public boolean estaVacia();
    public int cantidadElementos();
    public void mostrar();
    public int largoListaCola();
}
