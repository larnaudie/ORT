/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.tads;

/**
 *
 * @author Dell
 * @param <T>
 */
public class Cola<T> implements ICola<T> {

    private NodoCola<T> primero = null;
    private NodoCola<T> ultimo = null;
    private int cantidadElementos;

    public Cola() {
        primero = null;
        ultimo = null;
        cantidadElementos = 0;
    }

    @Override
    public void encolar(T dato) {
        NodoCola<T> nodoCola = new NodoCola<>();
        nodoCola.setDato(dato);
        if (estaVacia()) {
            primero = nodoCola;
            ultimo = nodoCola;
        } else {
            ultimo.setSiguiente(nodoCola);
            ultimo = nodoCola;
        }
        cantidadElementos++;
    }

    @Override
    public T desencolar() {

        if (estaVacia()) {
            throw new IllegalStateException("La Cola está vacía");
        }
        T dato = primero.getDato();
        primero = primero.getSiguiente();
        if (primero == null) {
            ultimo = null;
        }
        cantidadElementos--;
        return dato;
    }

    @Override
    public T primero() {
        if (estaVacia()) {
            throw new IllegalStateException("La Cola está vacía");
        }
        return primero.getDato();
    }

    @Override
    public boolean estaVacia() {
        
        return (primero == null) && (ultimo == null);
    }

    @Override
    public int cantidadElementos() {
        return cantidadElementos; 
    }

    @Override
    public void mostrar() {
        NodoCola<T> aux = primero;
        while (aux != null){
            System.out.println (aux.getDato());
            aux = aux.getSiguiente();
        }
    }
    
        //--------------------- FUNCIONES AGREGADAS ----------------------//
       
    @Override
    public int largoListaCola() {
        int count = 0;
        NodoCola aux = primero;
        while (aux != null) {
            count++;
            aux = aux.getSiguiente();
        }
        return count;
    }
}
