/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tads;

/**
 *
 * @author Admin
 */
public class ListaSE implements ILista {

    private Nodo inicio;
    private int cantidad;

    public ListaSE() {
        inicio = null;
        cantidad = 0;
    }

    @Override
    public boolean esVacia() {
        return inicio == null;
    }

    @Override
    public void agregarInicio(int n) {
        Nodo nuevo = new Nodo();
        nuevo.setDato(n);
        nuevo.setSiguiente(inicio);
        inicio = nuevo;
        cantidad++;
    }

    @Override
    public void agregarFinal(int n) {
        Nodo aux = inicio;

        if (aux == null) {
            Nodo nuevo = new Nodo();
            nuevo.setDato(n);
            inicio = nuevo;
            //aux = inicio;
        } else {
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            Nodo nuevo = new Nodo();
            nuevo.setDato(n);
            aux.setSiguiente(nuevo);
        }
        cantidad++;
    }

    @Override
    public void borrarInicio() {
        if (!esVacia()) {
            inicio = inicio.getSiguiente();
            cantidad--;
        }
    }

    @Override
    public void borrarFin() {

        if (!esVacia()) {

            if (inicio.getSiguiente() == null) {

                inicio = null;

            } else {

                Nodo aux = inicio;
                while ((Nodo) (aux.getSiguiente()).getSiguiente() != null) {
                    aux = aux.getSiguiente();
                }
                aux.setSiguiente(null);
            }
            cantidad--;
        }
    }

    @Override
    public void vaciar() {
        inicio = null;
        cantidad = 0;
    }

    @Override
    public void mostrar() {

        Nodo aux = inicio;
        while (aux != null) {
            System.out.println(aux.getDato());
            aux = aux.getSiguiente();
        }

    }

    /*
        Pre: La lista está ordenada ascendentemente.
        Pos: Inserta el elemento pasado como parámetro de forma ordenada en la lista.
     */
    public void insertarOrdenado(int elem) {
        if (esVacia()) {
            agregarInicio(elem);
        } else {
            // Caso lista de un elemento
            if (inicio.getSiguiente() == null) {
                int datoInicio = inicio.getDato();
                if (elem > datoInicio) {
                    agregarFinal(elem);
                } else {
                    agregarInicio(elem);
                }

            } else {
                int datoInicio = inicio.getDato();
                if (elem < datoInicio) {
                    agregarInicio(elem);
                } else {
                    //caso general
                    Nodo aux = inicio;
                    Nodo insertar = new Nodo();
                    insertar.setDato(elem);

                    while ((aux.getSiguiente() != null) && (aux.getSiguiente().getDato() < elem)) {
                        aux = aux.getSiguiente();
                    }

                    insertar.setSiguiente(aux.getSiguiente());
                    aux.setSiguiente(insertar);
                    cantidad++;

                }

            }
        }

    }

}
