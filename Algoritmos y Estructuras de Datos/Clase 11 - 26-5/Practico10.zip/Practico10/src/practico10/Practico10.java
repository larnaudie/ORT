/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practico10;

/**
 *
 * @author Admin
 */
public class Practico10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        mostrardsc(10);
        System.out.println("");
        mostrarasc(10);
        
        System.out.println("Factorial (5):" + factorial(5));
        
        String hola = "Hola";
        String inv = invertir(hola);
        System.out.println(inv);
        
        
    }
    
    //Muestra los números de n hasta 1
    // mostrardsc(5)
    // 5 4 3 2 1
    
    // mostrardsc(5)
    //  impr(5)
    //  mostrardsc(4)
    //      impr(4)
    //      mostrardsc(3)   
    
    public static void mostrardsc(int n){
         // CASO BASE n = 1
         if (n > 0){
             System.out.print(n + " ");
             mostrardsc(n-1);
         } 
    }
    
    //Muestra los números de 1 hasta n
    // mostrarasc(5)
    // 1 2 3 4 5
    public static void mostrarasc(int n){
        if (n > 0){
             mostrarasc(n-1);
             System.out.print(n + " ");
         } 
    }
    
    /*
    Ejercicio 1
    Implementar una función recursiva que calcule el factorial de un número natural N.
    Ejemplo: 5! = 5*4*3*2*1 = 120
    // caso 1! = 1
    */
    
    public static int factorial(int n){
    
        if (n == 1){
            return 1;
        } else {
            return n * factorial(n-1);
        }
    }
    
    
    /*
    * 
        Implementar un algoritmo recursivo que permita invertir una palabra.
        Ejemplo: Entrada: Hola Salida: aloH
        Firma a utilizar: H ola
                            invertir(ola)
                            imprimi H
    
        public String invertir(String palabra);
    */
    public static String invertir(String palabra){
        // palabra.charAt(i)
        // palabra.subString(desde)
        // Caso base palabra = ""
        if (palabra != ""){
            String res = invertir(palabra.substring(1));
            
            res += palabra.charAt(0);
            
            return res;

        }
        return "";
        
        // invertir("Hola")
         //     invertir("ola") 
         //         invertir("la")
         //             invertir("a")
         //                 invertir("")   
         //                 ret ""
         //             print(a)
         //         print(l)
         //     print("o"
         // print(H)
    }
    
    /*
    Ejercicio 5
        Implementar un algoritmo recursivo que permita sumar los elementos de un vector. Dibuje el
        diagrama de llamadas para el vector[] = {34,2,11,2} pos = 3
        Firma a utilizar: {34,2,11} + 2
                          {{34,2} + 11} + 2 
                          {{34} + 2} + 11} + 2 
        public int sumavector(int []v);

    */
    public static int sumaVector(int []v){
    
        return sumaVectorREC(v,v.length -1);
        
    }

    private static int sumaVectorREC(int[] v, int pos) {
        
        int ret;
        // caso base
        if (pos == 0){
            return v[0];
        } else {
            ret = v[pos] + sumaVectorREC(v, pos-1);
        }
        
        // formula recursiva
        
        return ret;
    }
    
    // sumaVectorREC (v, 3)
    //    sumaVectorREC (v, 2)
    
    /*
    Ejercicio 7
        Dado un arreglo de números enteros:
        a) Implementar una función recursiva que calcule el máximo valor del vector. Dibuje el
            diagrama de llamadas para el vector [] = {34,11,35,1}
        b) Implementar una función recursiva que calcule el mínimo valor del vector.
    
    */
    
    public static int maximo(int v[]){
        return maximoREC(v,0);
        
    }

    private static int maximoREC(int[] v, int pos) {
        int max;
        
        if (pos == v.length-1){ // CASO BASE
            max = v[pos]; // llegue al vector de tam 1
        } else {
            int maxRec = maximoREC(v, pos +1);
            if (v[pos] > maxRec) {
                max = v[pos];
            } else {
                max = maxRec;
            }
        }
        
        return max;
    }
    
    /*
        Ejercicio 8
            Dado un arreglo de números enteros, implementar una función recursiva que indique si se
            encuentra determinado número en un vector.
            a) Implementar una solución para un vector desordenado.
            b) Implementar una solución para un vector ordenado
    */

    // vector desordenado
    public static boolean estaElemento(int v[], int valor){
        return estaElementoREC(v, valor, 0);
    
    }

    private static boolean estaElementoREC(int[] v, int valor, int pos) {
        if (pos == v.length-1){ // CASO BASE
            return (v[pos] == valor); // llegue al vector de tam 1
        } else {
            boolean esValor = v[pos] == valor;
            if (esValor == true){
                return true;
            } else {
                return estaElementoREC(v,valor,pos+1);
            }
        }
    }
    
    public static boolean estaElementoOrdenado(int v[], int valor){
        return estaElementoREC(v, valor, 0);
    
    }

    private static boolean estaElementoOrdenadoREC(int[] v, int valor, int pos) {
        if (pos == v.length-1){ // CASO BASE
            return (v[pos] == valor); // llegue al vector de tam 1
        } else {
            boolean esValor = v[pos] == valor;
            if (esValor == true){
                return true;
            } else {
                if (v[pos] > valor){
                    return false;
                }
                return estaElementoOrdenadoREC(v,valor,pos+1);
            }
        }
    }
    
    
}
