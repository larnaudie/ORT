/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practico11;

import tads.ListaSE;

/**
 *
 * @author hcepeda
 */
public class Practico11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ListaSE lista1 = new ListaSE();
        
        lista1.agregarFinal(4);
        lista1.agregarFinal(8);
        lista1.agregarFinal(7);
        lista1.agregarFinal(3);
        lista1.agregarFinal(6);
        
        lista1.mostrarInverso();
        
    }
    
}
