
package tads;

/**
 *
 * @author Admin
 */
public interface ILista {
    
    public boolean esVacia();
    
    public void agregarInicio(int n);
    
    public void agregarFinal(int n);
    
    public void borrarInicio();

    public void borrarFin();

    public void vaciar();

    public void mostrar();
    
}
