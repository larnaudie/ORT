/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 * 
        Cree la clase Persona con los siguientes atributos: nombre, apellido y edad (variables de instancia)
            a. Agregue los métodos de acceso y modificación.
            b. Crear un objeto.
            c. Crear un constructor que recibe nombre, apellido y edad.
            d. Crear un objeto usando el constructor con parámetros y mostrar por consola los datos del
            objeto.
 */
public class Persona {
    
    private String nombre;
    private String apellido;
    private int edad;
    
    private static int nroPersona;


    
    public Persona(String nombre, String apellido, int edad){
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString(){
        return nombre + apellido + edad;
    }
  
    
    
}
