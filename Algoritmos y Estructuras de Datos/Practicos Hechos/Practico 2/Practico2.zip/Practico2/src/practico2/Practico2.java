/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practico2;

import ejercicio1.Persona;

/**
 *
 * @author Admin
 */
public class Practico2 {


    public static void main(String[] args) {

        
        Persona persona2 = new Persona("Carlos", "Perez", 20);
        System.out.println(persona2);
    }
    
    /*
        Cree la clase Persona con los siguientes atributos: nombre, apellido y edad (variables de instancia)
            a. Agregue los métodos de acceso y modificación.
            b. Crear un objeto.
            c. Crear un constructor que recibe nombre, apellido y edad.
            d. Crear un objeto usando el constructor con parámetros y mostrar por consola los datos del
            objeto.
    */
}
