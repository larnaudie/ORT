/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practico1;

/**
 *
 * @author Admin
 */
public class Practico1 {

    public static void main(String[] args) {
        ejercicio2(2, 10);
    }

    /*
         Implemente un método que, dado dos números enteros, muestre por pantalla:
            • Su promedio, con decimales.
            • La cantidad de números pares que existen entre ellos.
    */
    
    private static void ejercicio2(int a, int b){
        // Promedio
        
        double promedio = ((double)a + b) / 2;
        
        System.out.println("Promedio=" + promedio);
    
        //Promedio=2
        //Promedio=2.0
        int pares = 0;
        for (int i = a; i<=b; i++){
            if ((i%2)==0){
                pares++;
            }
        }
        System.out.println("Pares:" + pares);
        
        
        ejercicio4(2365);
        
    }
    
    /*
        Implemente un método que reciba un número entero positivo e imprima en pantalla sus dígitos
        por separado.
        Pruebe el método con los siguientes valores: 5, 1523, 20, 100000.
    */
    
    public static void ejercicio4(int valor){
        //1523 1 5 2 3
        String valorString = "" + valor;
        
        for (int i=0; i < valorString.length();i++){
            System.out.print(valorString.charAt(i) + " ");
        }
    
    }

    
}
