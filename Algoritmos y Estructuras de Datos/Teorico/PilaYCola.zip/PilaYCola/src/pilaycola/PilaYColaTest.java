/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pilaycola;

import pila.Pila;

/**
 *
 * @author Admin
 */
public class PilaYColaTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pila<Integer> p = new Pila();

        p.apilar(4);
        p.apilar(6);
        p.apilar(2);

        p.mostrar();

        System.out.println("----------------------------------");
        Pila<Integer> copia = p.copiarPila();
        copia.mostrar();
        System.out.println("----------------------------------");
        p.mostrar();


    }

}
