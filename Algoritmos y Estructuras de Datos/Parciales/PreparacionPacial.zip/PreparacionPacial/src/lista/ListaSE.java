/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista;

import pila.Pila;

/**
 *
 * @author Admin
 */
public class ListaSE implements ILista {

    private Nodo inicio;

    private int cantidadElementos;

    public ListaSE() {
        inicio = null;
        cantidadElementos = 0;
    }

    @Override
    public boolean esVacia() {
        return inicio == null;
    }

    @Override
    public void agregarInicio(int n) {
        Nodo nuevo = new Nodo();
        nuevo.setDato(n);
        nuevo.setSiguiente(inicio);
        inicio = nuevo;
        cantidadElementos++;
    }

    @Override
    public void agregarFinal(int n) {
        Nodo aux = inicio;

        if (aux == null) {
            Nodo nuevo = new Nodo();
            nuevo.setDato(n);
            inicio = nuevo;
            //aux = inicio;
        } else {
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            Nodo nuevo = new Nodo();
            nuevo.setDato(n);
            aux.setSiguiente(nuevo);
        }
        cantidadElementos++;
    }

    @Override
    public void borrarInicio() {
        if (!esVacia()) {
            inicio = inicio.getSiguiente();
            cantidadElementos--;
        }

    }

    @Override
    public void borrarFin() {

        if (!esVacia()) {

            if (inicio.getSiguiente() == null) {

                inicio = null;

            } else {

                Nodo aux = inicio;
                while ((Nodo) (aux.getSiguiente()).getSiguiente() != null) {
                    aux = aux.getSiguiente();
                }
                aux.setSiguiente(null);
            }
            cantidadElementos--;
        }
    }

    @Override
    public void vaciar() {
        inicio = null;
        cantidadElementos = 0;
    }

    @Override
    public void mostrar() {

        Nodo aux = inicio;
        while (aux != null) {
            System.out.print(aux.getDato());
            aux = aux.getSiguiente();
            if (aux != null) {
                System.out.print("-");
            } else {
                System.out.println("");
            }
        }

    }

    /*
        void insertarOrdenado (int elem);
        Pre: La lista está ordenada ascendentemente.
        Pos: Inserta el elemento pasado como parámetro de forma ordenada en la lista.
    
     */
    public void insertarOrdenado(int elem) {
        if (esVacia()) {
            agregarInicio(elem);
        } else {
            // Caso lista de un elemento
            if (inicio.getSiguiente() == null) {
                int datoInicio = inicio.getDato();
                if (elem > datoInicio) {
                    agregarFinal(elem);
                } else {
                    agregarInicio(elem);
                }

            } else {
                int datoInicio = inicio.getDato();
                if (elem < datoInicio) {
                    agregarInicio(elem);
                } else {
                    //caso general
                    Nodo aux = inicio;
                    Nodo insertar = new Nodo();
                    insertar.setDato(elem);

                    while ((aux.getSiguiente() != null) && (aux.getSiguiente().getDato() < elem)) {
                        aux = aux.getSiguiente();
                    }

                    insertar.setSiguiente(aux.getSiguiente());
                    aux.setSiguiente(insertar);

                    cantidadElementos++;

                }
            }
        }

    }

    @Override
    public int cantidadElementos() {
        return cantidadElementos;
    }

    @Override
    public boolean existeElemento(int elemento) {
        Nodo actual = inicio;
        boolean existe = false;

        while (actual != null && !existe) {
            if (actual.getDato() == elemento) {
                existe = true;
            }
            actual = actual.getSiguiente();
        }

        return existe;
    }

    @Override
    public Nodo obtenerElemento(int elemento) {
        Nodo actual = inicio;
        boolean encontre = false;

        while ((actual != null) && (!encontre)) {
            if (actual.getDato() == elemento) {
                encontre = true;
            }
            actual = actual.getSiguiente();
        }
        return actual;
    }

    @Override
    public Nodo obtenerElementoPosicion(int posicion) {
        Nodo actual = inicio;
        int indice = 1;

        while ((actual != null) && (indice < posicion)) {
            actual = actual.getSiguiente();
            indice++;
        }
        return actual;

    }


    // Elimina el elemento si lo encuentra y su anterior en caso de existir
    public void eliminar2Elementos(int elemento){
        if(inicio != null){
            Nodo actual = inicio;
            boolean encontre = false;
            
            if (actual.getDato() == elemento){ // Caso borro el primer elemento
                inicio = actual.getSiguiente();
                encontre = true;
            }
            
            if ((actual.getSiguiente()!= null)&&(actual.getSiguiente().getDato() == elemento)){ // borro segundo elemento
                inicio = actual.getSiguiente().getSiguiente();
                encontre = true;
            }
        
            
            while((!encontre)&&(actual.getSiguiente()!=null&&(actual.getSiguiente().getSiguiente()!=null))){
                if(actual.getSiguiente().getSiguiente().getDato() == elemento){
                    encontre = true;
                    actual.setSiguiente(actual.getSiguiente().getSiguiente().getSiguiente());
                } else {
                    actual = actual.getSiguiente();
                    
                }
            
            
            }
        
        }
    }
    
    /*
        Implemente un metodo recursivo que coloque todos los elementos de la lista mayores a C en la pila. El primer elemento 
        que cumpla la condicion debe estar en el tope de la pila
    
        ->5->7->2->4->6
    
        genererPila(4)
        
        5 <- tope
        7
        6
    
    
    */
    
    public Pila generarPila(int C){
        Pila pila = new Pila();
        generarPilaREC(inicio,pila, C);
        return pila;
    }

    private void generarPilaREC(Nodo aux, Pila pila, int C) {
        if(aux!=null){
            
            generarPilaREC(aux.getSiguiente(), pila, C);
            if(aux.getDato() > C){
                pila.apilar(aux.getDato());
            }

        }
        // CASO BASE
        
    }
 
    
    
    
    
}


