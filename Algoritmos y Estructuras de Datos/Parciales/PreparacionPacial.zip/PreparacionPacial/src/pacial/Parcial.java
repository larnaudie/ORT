package pacial;

import java.util.Arrays;
import lista.ListaSE;
import pila.*;

/**
 *
 * @author Admin
 */
public class Parcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int[] vec = {4, 7, 9, 12, 16, 20};

        System.out.println("Busq(9): " + buscarB(vec, 0, vec.length-1, 9));
        
        
        int [][] m = {{1,2,3},{4,5,6},{7,8,9}};
        Pila p = sumaFilas(m);
        System.out.println(Arrays.toString(m));
        p.mostrar();
        
        int [][] m2 = {{1,2,1},{4,5,6},{7,8,9}};
        
        System.out.println("DIAGONALES IGUALES: "+ diagonalesIguales(m2));
        
        System.out.println("SUMA POS: " + sumaPos(vec, 1, 3));
        
        //System.out.println("SUMA VEC: " + sumaPos(vec, 2, 4));
        
        
        ListaSE lista = new ListaSE();
        lista.agregarFinal(3);
        lista.agregarFinal(6);
        lista.agregarFinal(7);
        lista.agregarFinal(8);
        lista.agregarFinal(9);
        lista.agregarFinal(10);
        lista.agregarFinal(11);
        
        System.out.println("MOSTRANDO IMPARES");
        mostrarUltNImpares(lista, 3);
        
        
        
    }

    public static boolean buscarB(int vec[], int inf, int sup, int buscado){
    
        if(inf > sup){ //CASO BASE
            return false;
        } else {
            
            int medio = inf + sup / 2;
            if (buscado == vec[medio]){
                return true;
            } else {
                if (buscado > vec[medio]){
                    // busco en la dercha
                    return buscarB(vec, medio+1, sup, buscado);
                } else {
                    //busco en la izquierda
                    return buscarB(vec, inf, medio-1, buscado);
                }
            }
            
        
        }
    
    }
    
    public static boolean buscarB_Iterativo(int vec[], int inf, int sup, int buscado){
    
        while(inf <= sup){ 
            
            int medio = inf + sup / 2;
            if (buscado == vec[medio]){
                return true;
            } else {
                if (buscado > vec[medio]){
                    // busco en la dercha
                    inf = medio+1;
                    //return buscarB(vec, medio+1, sup, buscado);
                } else {
                    //busco en la izquierda
                    sup = medio-1;
                    //return buscarB(vec, inf, medio-1, buscado);
                }
            }
        }
        return false;
        
    }
    
    public static int[] maximoDeColumnas(int m[][]){
        int ret[] = new int[m[0].length];
        
        for (int col = 0; col < m[0].length; col++){
            int max = m[0][col];
            for (int fila = 1; fila < m.length; fila++){
                if (m[fila][col] > max){
                    max = m[fila][col];
                }
            }
            ret[col] = max;
        }
        return ret;
    }
    
    
    // [1 2 3] ->6
    // [4 5 6] ->6:15
    // [7 8 9] ->6:15:24
    
    
    public static Pila sumaFilas(int m[][]){
    
        Pila<Integer> pila = new Pila();
        
        for (int fila=m.length-1; fila >=0; fila--){
            int suma = 0;
            for (int col=0; col < m[fila].length; col++){
                suma += m[fila][col];
            }
            pila.apilar(suma);
        }
        /*
        Pila<Integer> auxPila = new Pila();
        
        while(!pila.estaVacia()){
            auxPila.apilar(pila.desapilar());
        }
        */
        
        return pila;
    }
    
    // Suma de diagonales son iguales
    
    public static boolean diagonalesIguales(int [][] m){
    
        int sumaD1=0;
        int sumaD2=0;
        
        for (int i=0; i < m.length; i++){
            sumaD1 += m[i][i];
            sumaD2 += m[i][m.length-1-i];
        }
    
        return sumaD1 == sumaD2;
    
    }
    
    /*
        Devuelve la suma desde la posicion desde-hasta incusive
        recursivo
    
        {3,4,6,8,5,3,4}
        sumaPos(2,4) 
            5 + sumaPos(2,3)= 5+ 8 + 6
                8 + sumaPos(2,2)= 8+6
                    sumaPos(2,2)=6 // caso base
    */
    
    public static int sumaPos(int v[], int desde, int hasta){
        if (desde == hasta){ // caso base
            return v[desde];
        } else {
            // dejamos fijo desde y vamos decrementando hasta
            return sumaPos(v, desde, hasta-1) + v[hasta];
        }
        
        
    }
    
    
    public static void mostrarUltNImpares(ListaSE lista, int n){
        if (lista != null){
            mostrarUltNImparesREC(lista, n, lista.cantidadElementos());
        
        }
    
    }

    private static void mostrarUltNImparesREC(ListaSE lista, int restantes, int pos) {
        if((pos > 0)&&(restantes>0)){
            int dato = lista.obtenerElementoPosicion(pos).getDato();
            if(dato % 2 != 0){
                // Es impar
                System.out.println(dato);
                mostrarUltNImparesREC(lista, restantes-1, pos-1);
            } else {
                mostrarUltNImparesREC(lista, restantes, pos-1);
                
            }
            
        
        }
        // CASO BASE
        
    }
    
    // Recursivo
    public static void eliminarMayores(Pila p, int n){
        if (!p.estaVacia()){
            int elemento = (int) p.desapilar();
            
            eliminarMayores(p, n);
            
            if(elemento <=n){
                p.apilar(elemento);
            }
            
            
        }
        // CASO BASE
    
    }
    
    /*
        [1 2 4 5 6]
        [3 2 4 3 6 8]
        [6 2 2 2 6]
        [8 2 4 5 6]
        [1 2 4 5 6]
    */
    
    public static boolean hayTresConsecutivosIguales(int m[][]){
        
        for(int fila = 0; fila < m.length; fila++){
            for(int col = 0; col < m[fila].length-2; col++){
                if(((m[fila][col])==(m[fila][col+1]))&& ((m[fila][col])==(m[fila][col+2]))){
                    return true;
                }
            }
        }
        return false;
    }
    
    
    
}
