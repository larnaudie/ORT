/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista;

/**
 *
 * @author Admin
 */
public class ListaSE implements ILista {

    private Nodo inicio;

    private int cantidadElementos;

    public ListaSE() {
        inicio = null;
        cantidadElementos = 0;
    }

    @Override
    public boolean esVacia() {
        return inicio == null;
    }

    @Override
    public void agregarInicio(int n) {
        Nodo nuevo = new Nodo();
        nuevo.setDato(n);
        nuevo.setSiguiente(inicio);
        inicio = nuevo;
        cantidadElementos++;
    }

    @Override
    public void agregarFinal(int n) {
        Nodo aux = inicio;

        if (aux == null) {
            Nodo nuevo = new Nodo();
            nuevo.setDato(n);
            inicio = nuevo;
            //aux = inicio;
        } else {
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            Nodo nuevo = new Nodo();
            nuevo.setDato(n);
            aux.setSiguiente(nuevo);
        }
        cantidadElementos++;
    }

    @Override
    public void borrarInicio() {
        if (!esVacia()) {
            inicio = inicio.getSiguiente();
            cantidadElementos--;
        }

    }

    @Override
    public void borrarFin() {

        if (!esVacia()) {

            if (inicio.getSiguiente() == null) {

                inicio = null;

            } else {

                Nodo aux = inicio;
                while ((Nodo) (aux.getSiguiente()).getSiguiente() != null) {
                    aux = aux.getSiguiente();
                }
                aux.setSiguiente(null);
            }
            cantidadElementos--;
        }
    }

    @Override
    public void vaciar() {
        inicio = null;
        cantidadElementos = 0;
    }

    @Override
    public void mostrar() {

        Nodo aux = inicio;
        while (aux != null) {
            System.out.print(aux.getDato());
            aux = aux.getSiguiente();
            if (aux != null) {
                System.out.print("-");
            } else {
                System.out.println("");
            }
        }

    }

    /*
        void insertarOrdenado (int elem);
        Pre: La lista está ordenada ascendentemente.
        Pos: Inserta el elemento pasado como parámetro de forma ordenada en la lista.
    
     */
    public void insertarOrdenado(int elem) {
        if (esVacia()) {
            agregarInicio(elem);
        } else {
            // Caso lista de un elemento
            if (inicio.getSiguiente() == null) {
                int datoInicio = inicio.getDato();
                if (elem > datoInicio) {
                    agregarFinal(elem);
                } else {
                    agregarInicio(elem);
                }

            } else {
                int datoInicio = inicio.getDato();
                if (elem < datoInicio) {
                    agregarInicio(elem);
                } else {
                    //caso general
                    Nodo aux = inicio;
                    Nodo insertar = new Nodo();
                    insertar.setDato(elem);

                    while ((aux.getSiguiente() != null) && (aux.getSiguiente().getDato() < elem)) {
                        aux = aux.getSiguiente();
                    }

                    insertar.setSiguiente(aux.getSiguiente());
                    aux.setSiguiente(insertar);

                    cantidadElementos++;

                }
            }
        }

    }

    @Override
    public int cantidadElementos() {
        return cantidadElementos;
    }

    @Override
    public boolean existeElemento(int elemento) {
        Nodo actual = inicio;
        boolean existe = false;

        while (actual != null && !existe) {
            if (actual.getDato() == elemento) {
                existe = true;
            }
            actual = actual.getSiguiente();
        }

        return existe;
    }

    @Override
    public Nodo obtenerElemento(int elemento) {
        Nodo actual = inicio;
        boolean encontre = false;

        while ((actual != null) && (!encontre)) {
            if (actual.getDato() == elemento) {
                encontre = true;
            }
            actual = actual.getSiguiente();
        }
        return actual;
    }

    @Override
    public Nodo obtenerElementoPosicion(int posicion) {
        Nodo actual = inicio;
        int indice = 1;

        while ((actual != null) && (indice < posicion)) {
            actual = actual.getSiguiente();
            indice++;
        }
        return actual;

    }



}


