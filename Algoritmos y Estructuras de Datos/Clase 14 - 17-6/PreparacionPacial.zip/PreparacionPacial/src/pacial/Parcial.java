package pacial;

import java.util.Arrays;
import lista.ListaSE;
import pila.*;

/**
 *
 * @author Admin
 */
public class Parcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int[] vec = {4, 7, 9, 12, 16, 20};

    }

    
}
