/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practico3;

/**
 *
 * @author Admin
 */
public class Practico3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a = 10;
        
        int v[] = new int[9];
        v[0] = 5;
        v[1] = 9;
        v[2] = 19;
        
        v[8] = 24;
        
        int v2[] = {3,6,2,5,7};
        mostrarVector(v2);
        System.out.println("Promedio: " + promedio(v2));
        System.out.println("Impares: " + muestroValoresImpares(v2));

        System.out.println("PosMin: " + posMinVec2(v2, 0, 3));
        
        System.out.println("BuscarVec (2): " + buscarVec(v2,17));
        
        
        
    }
    
    //int v2[] = {3,6,2,5};
    // 3-6-2-5
    public static void mostrarVector(int v[]){
        
        for(int i=0; i < v.length; i++){
            System.out.print(v[i]);
            if(i<v.length-1){
                System.out.print("-");
            }
        }
    
    }
    
    /*
    Implementar una función que calcule el promedio de los valores contenidos en un array de enteros.
    Firma: public static double promedio(int []v);
    */
    
    public static double promedio(int []v){
    
        int suma = 0;
        for(int i=0; i < v.length; i++){
            suma += v[i];
        }
 
        return (double)suma / v.length;
        
    }
    

    /*
    PRE:
        - v no es vacío
        - 
    
    POST:
        - Retorna un String con los valores impares del vector
    */
    public static String muestroValoresImpares(int v[]){
        String res = "";
        for(int i=0; i < v.length; i++){
            if((v[i] % 2)!=0){
                res += v[i] + " ";
            }
        }
        return res;      
    }
    /* 
     * Caso 1: se asume que el array no está vacío y no esta ordenado 
     * PRE: Recibe un arreglo de enteros
     * POS: Retorna el máximo valor
     * 
     * @param {int[]} arreglo
     * @return {int}
     */
    public static int maxValue(int[] arreglo) {
        int aux = arreglo[0];
        for (int i = 1; i < arreglo.length; i++) {
            if (arreglo[i] > aux) {
                aux = arreglo[i];
            }
        }
        return aux;
    }
    
    public static int maxValue2(int[] arreglo) {
        int aux = Integer.MIN_VALUE;
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] > aux) {
                aux = arreglo[i];
            }
        }
        return aux;
    }
    
    /*
    * PRE: 
        - v no es vacío
        - v está ordenado en forma ascendete
    POST: 
        - devuelve el máximo valor de v
    
    **/
    
    public static int maxValueOrdenado( int[] v){
        return v[v.length-1];
    
    }
    
    /*
    Implementar una función que retorne la posición del menor valor dentro de un rango específico
        del array (posiciones dadas).
        {3,4,1,5,8,12}    
        posMinVec(v,3,5) =2
        min v[2] = 1
    
    
    */

    public static int posMinVec(int []v,int posDesde, int posHasta){
        int minimo = v[posDesde];
        int posMinimo = posDesde;
    
        for(int i = posDesde+1; i <= posHasta; i ++){
            if (v[i] < minimo){
                minimo = v[i];
                posMinimo = i;
            }
        }
        return posMinimo;
    }
    

    public static int posMinVec2(int []v,int posDesde, int posHasta){
        int posMinimo = posDesde;
    
        for(int i = posDesde+1; i <= posHasta; i ++){
            if (v[i] < v[posMinimo]){
                posMinimo = i;
            }
        }
        return posMinimo;
    }

    // Caso 1 - Vector No ordenado
    
    

    
    public static boolean buscarVec(int[] v, int element){
        boolean notExist = false;
        for(int i=0;((i<v.length)&&(!notExist)); i++){
            if(v[i] == element){
                notExist = true;
            }
        }
        return notExist;
    }
    
    /*
    PRE: v está ordenado ascendete
    
    */

    // Caso 2 - Vector ordenado secuencial
    public static boolean buscarVecOrd(int[] v, int element){
        boolean notExist = false;
        for(int i=0;((i<v.length)&&(!notExist)&&(v[i]<=element)); i++){
            if(v[i] == element){
                notExist = true;
            }
            
        }
        return notExist;
    
    }
    
    // Caso 3 - Vector ordenado por punto medio
    public static boolean buscarVecOrdMedio(int[] v, int element){
        boolean encontre = false;
        int desde, hasta;
        desde = 0; //prinicio
        hasta = v.length -1;
        int medio;
        
        while((!encontre) && (desde < hasta)){
            medio = (desde + hasta ) / 2;
            if (v[medio] == element){
                encontre = true;
            }
            
            // v[4]==22 element = 15
            if (v[medio] > element){
                hasta = medio -1;
            }

            if (v[medio] < element){
                desde = medio +1;
            }
        }
    
        return encontre;
    
    }
    
    
    /*
        Dado dos vectores v1 y v2, ambos ordenados en forma ascendente, implementar una función
        que retorne un nuevo vector ordenado que contenga los elementos de ambos.
        Firma: public static int [] unirVectoresOrdenados(int []v1, int []v2);
    
    */
    
    public static int [] unirVectoresOrdenados(int []v1, int []v2) {
        int v3[] = new int[v1.length + v2.length];
        
        int largoV1 = v1.length;
        int largoV2 = v2.length;
        
        int indiceV1 = 0;
        int indiceV2 = 0;
        
        for (int i=0; i< v3.length; i++){
        
            if ((indiceV1 < largoV1) && (indiceV2 < largoV2)){ // Tengo elementos en ambos vectores v1 y v2
                
                if(v1[indiceV1] < v2[indiceV2]){
                    v3[i] = v1[indiceV1];
                    indiceV1++;
                } else {
                    v3[i] = v2[indiceV2];
                    indiceV2++;
                }
            } else { // algun vector ya no tiene elementos
                if (indiceV1 < largoV1){
                    // Le quedaban elementos a V1
                    v3[i] = v1[indiceV1];
                    indiceV1++;
                   
                } else {
                    // Le quedaban elementos a V2
                    v3[i] = v2[indiceV2];
                    indiceV2++;
   
                }
            
            }

        }
        return v3;
    
    }
    
}
