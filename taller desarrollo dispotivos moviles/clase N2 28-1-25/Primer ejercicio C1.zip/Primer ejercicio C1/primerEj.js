window.addEventListener("load", inicio);

function inicio(){

document.querySelector("#btnElegir").addEventListener("click",elegirPais);
document.querySelector("#btnRegistrar").addEventListener("click",registrarJug);

}


class Jugador {
    constructor(nombre, pais, equipo) {
        this.nombre = nombre;
        this.pais = pais;
        this.equipo = equipo;
    }
}

let jugadores = new Array();



function elegirPais() {
    let pais = document.querySelector("#slcPais").value;
    let optionEquipo = "";

    let equipoES = ["Real Madrid","Barcelona","Atlético Madrid"];
    let equipoIT = ["Milan","Juventus","Inter"];
    
    if (pais == "es") {

        for (let eq of equipoES){
        optionEquipo += `<option value="${eq}">${eq}</option>`;
        }

    }else if(pais == "it"){

        for (let eq of equipoIT){
            optionEquipo += `<option value="${eq}">${eq}</option>`;
        }
    }
    
    document.querySelector("#slcEquipo").innerHTML = optionEquipo;   

}

function registrarJug() {
    let nombre = document.querySelector("#txtNombre").value;
    let pais = document.querySelector("#slcPais").value;
    let equipo = document.querySelector("#slcPais").value;

    if (equipo != "" && pais != "") {
        jugadores.push(nombre, pais, equipo);
        alert("Exito");
    }
}
