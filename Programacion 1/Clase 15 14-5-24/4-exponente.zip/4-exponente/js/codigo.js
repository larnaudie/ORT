window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnCalcular").addEventListener("click", tomarValores);
}

function tomarValores() {
    let msg = "";
    let base = Number(document.querySelector("#txtBase").value);
    let exponente = Number(document.querySelector("#txtExponente").value);

    if (!isNaN(base) && !isNaN(exponente)) {
        let resultado = calcularPotencia(base, exponente);
        msg = "El resultado es " + resultado;
    }
    else {
        msg = "Error. Uno o ambos valores no son numéricos.";
    }
    document.querySelector("#pResultado").innerHTML = msg;
}

function calcularPotencia(base, exponente) {
    let resultado = base;
    //console.log(Math.pow(base, exponente))
    if (exponente > 0) {
        for (i = 2; i <= exponente; i++) {
            resultado = resultado * base;
        }
    } else if (exponente === 0) {
        resultado = 1;
    } else {
        exponente = exponente * -1;
        for (i = 2; i <= exponente; i++) {
            resultado = resultado * base;
        }
        resultado = 1 / resultado;
    }
    return resultado;
}