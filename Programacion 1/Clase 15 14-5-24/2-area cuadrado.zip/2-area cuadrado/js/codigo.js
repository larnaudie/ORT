window.addEventListener("load", inicio);


function inicio() {
  document.querySelector("#btnCuadrado").addEventListener("click", tomarValoresAreaCuadrado);
}

function tomarValoresAreaCuadrado() {
  let lado = Number(document.querySelector("#txtLado").value);//4
  let msj = "";
  let area;

  if(lado > 0 && !isNaN(lado)){
    area = calcularAreaCuadrado(lado);
  }else{
    area = -1;
  }

  msj = `El area del cuadrado es ${area}`;

  document.querySelector("#pResultado").innerHTML = msj;
}
