function tirarDado() {
    let numeroAleatorio = Math.ceil(Math.random() * 6);
    return numeroAleatorio;
}

function sumarValores(a, b) {
    let suma = a + b;
    return suma;
}

function restaValores(a, b) {
    let resta = a - b;
    return resta;
}

function dividirValores(a, b) {
    let dividir = a / b;
    return dividir;
}

function multiplicarValores(a, b) {
    let mul = a * b;
    return mul;
}

function calcularAreaCuadrado(ladoCuadrado) {
    let calculoArea = ladoCuadrado * ladoCuadrado;
    return calculoArea;
  }