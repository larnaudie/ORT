window.addEventListener("load", inicio);

function inicio() {
    document.querySelector("#btnInvertir").addEventListener("click", InvertirTexto);
    //document.querySelector("#btnInvertir").addEventListener("click", tomarDatos);
}

function InvertirTexto() { 
    let stringOriginal = document.querySelector("#txtPalabra").value;
    let stringDadoVuelta = "";

    for(let i = stringOriginal.length -1; i >= 0; i--) {
        stringDadoVuelta += stringOriginal.charAt(i);
    }
    document.querySelector("#pResultado").innerHTML = stringDadoVuelta;
}
