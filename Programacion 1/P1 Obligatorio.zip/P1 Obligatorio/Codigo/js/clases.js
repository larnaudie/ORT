//Aca van a ir las clases; Objetos que nos permiten crear mas objetos

class Usuario {
    constructor(unId, unNombreUsuario, unaClave) {
        this.id = unId;
        this.nombre = unNombreUsuario;
        this.contrasena = unaClave;
    }
}

class Admin {
    constructor(unId, unNombreUsuarioAdmin, unaClave){
        this.id = unId;
        this.nombre = unNombreUsuarioAdmin;
        this.contrasena = unaClave;
    }
}