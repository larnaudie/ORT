window.addEventListener("load", inicio);

function inicio() {
    /**Cargamos todos los escuchadores de eventos */
    document.querySelector("#btnMostrar").addEventListener("click", mostrarTabla);
    document.querySelector("#btnRegistrar").addEventListener("click", registrarUsuario);
    document.querySelector("#btnLogin").addEventListener("click", hacerLogin);
    document.querySelector("#menuSalir").addEventListener("click", salir);

    /*Por defecto el programa arranca ocultando todas las secciones primero. */
    ocultarSecciones();

    /*Toma las clases de la tabla del NAV y al escuchar que se hace click en una de ellas muestra esa seccion. */
    let botones = document.querySelectorAll(".btnSeccion");
    for (let i = 0; i < botones.length; i++) {
        botones[i].addEventListener("click", mostrarSeccion);
    }

    /*Mostramos la seccion del login con id seccionLogin y ocultamos la barra de navegacion para impedir que vayan directo al carrito u otros menus*/
    document.querySelector("#seccionLogin").style.display = "block";
    document.querySelector("#navPrincipal").style.display = "none";

    /*Si se hace click en Registrarse, se muestra la seccion Registro. */
    document.querySelector("#btnMostrarRegistro").addEventListener("click", mostrarSeccionRegistro);
    /*Si se hace click en Vovler al Login, se oculta la seccion Registro. */
    document.querySelector("#btnOcultarRegistrar").addEventListener("click", ocultarSeccionRegistro);

}

//-----------------------------FUNCIONES DE NAVEGACION-------------------------------------------------------

/*Muestra la seccion de la tabla*/
function mostrarSeccion() {
    //primero oculta todo.
    ocultarSecciones();

    let idBtn = this.getAttribute("id");//"btnSeccionAgregar"
    let idSeccion = idBtn.charAt(3).toLowerCase() + idBtn.substring(4);//seccionAgregar
    console.log(idBtn, idSeccion);
    document.querySelector("#" + idSeccion).style.display = "block"
}

function mostrarSeccionRegistro() {
    document.querySelector("#seccionRegistro").style.display = "block"
    document.querySelector("#seccionLogin").style.display = "none";
}

function ocultarSeccionRegistro() {
    document.querySelector("#seccionRegistro").style.display = "none"
    document.querySelector("#seccionLogin").style.display = "block";
}


function ocultarSecciones() {
    let secciones = document.querySelectorAll(".seccion");
    for (let i = 0; i < secciones.length; i++) {
        secciones[i].style.display = "none"
    }
}

function mostrarBotones(tipo) {
    ocultarBotones();

    let botonesMostrar = document.querySelectorAll("." + tipo);
    for (let i = 0; i < botonesMostrar.length; i++) {
        botonesMostrar[i].style.display = "block";
    }
}

function ocultarBotones() {
    let botonesOcultar = document.querySelectorAll(".btnSeccion");
    for (let i = 0; i < botonesOcultar.length; i++) {
        botonesOcultar[i].style.display = "none";
    }
}

//-------------------------------- FUNCIONES DE ACCESO Y REGISTRO --------------------------------------------------

/*REGISTRAR USUARIO*/

let idUsuario = 5;
// let idUsuario = sistema.usuarios.length + 1;
function registrarUsuario() {
    let nombre = document.querySelector("#txtUsuarioRegistro").value;
    let clave = document.querySelector("#txtContraseña").value;
    let numeroTarjeta = document.querySelector("#txtTarjetaCredito").value;
    let numeroCVC = document.querySelector("#txtCVC").value;

    let camposCompletos = sistema.validarCamposVaciosRegistro(nombre, clave);
    let formatoContrasenaValido = sistema.verificarFormatoContrasena(clave);
    let formatoTarjetaValido = sistema.verificarTarjetaCredito(numeroTarjeta);
    let formatoCVCValido = sistema.verificarCVC(numeroCVC);
    let existeUsuario = sistema.buscarNombre(sistema.usuarios, "nombre", nombre);
    let verificarTajeta = sistema.verificarTarjetaCreditoLuhn(numeroTarjeta);

    if (camposCompletos === true && formatoContrasenaValido === true && existeUsuario === false && formatoTarjetaValido === true && formatoCVCValido === true && verificarTajeta === true) {
        let usuario = new Usuario(idUsuario, nombre, clave);
        idUsuario++;
        sistema.agregarUsuario(usuario);
        alert("Registro exitoso!")
    } else {
        alert("Error en Registro: Los campos son todos obligatorios, la pass es minimo de 5 caracteres o ya existe un usuario con ese nombre");
    }
    document.querySelector("#txtUsuarioRegistro").value = "";
    document.querySelector("#txtContraseña").value = "";
}

let usuarioLogeado = null;
let usuarioLogeadoAdmin = null;
let tipoUsuario = "";

function hacerLogin() {
    let nombre = document.querySelector("#txtUsuario").value;
    let clave = document.querySelector("#txtClave").value;
    tipoUsuario = document.querySelector("#slcTipoUsuario").value;

    let login = sistema.verificarLogin(nombre, clave, tipoUsuario);

    if (login) {
        usuarioLogeado = sistema.obtenerObjeto(sistema.usuarios, "nombre", nombre);
        usuarioLogeadoAdmin = sistema.obtenerObjeto(sistema.usuariosAdmin, "nombre", nombre);
        mostrarMenuOcultandoLoginYRegistro();
    } else {
        alert("Usuario y/o contraseña incorrectos");
    }

    /**Una vez logeado, restaura los datos a vacios*/
    document.querySelector("#txtUsuario").value = "";
    document.querySelector("#txtClave").value = "";
}

function mostrarMenuOcultandoLoginYRegistro() {
    mostrarBotones(tipoUsuario);
    document.querySelector("#seccionLogin").style.display = "none";
    document.querySelector("#seccionRegistro").style.display = "none";
    document.querySelector("#navPrincipal").style.display = "block";
    /*Vuelve a mostrar el texto, sino al apretar salir, queda oculto cuando se reingresa */
    document.querySelector("#aux").style.display = "block";

    if (tipoUsuario === "user") {
        document.querySelector("#nombreUsuarioLogeado").innerHTML = `Bienvenido ${usuarioLogeado.nombre}`
    }
    if (tipoUsuario === "admin"){
        document.querySelector("#nombreUsuarioLogeado").innerHTML = `Bienvenido ${usuarioLogeadoAdmin.nombre}`
    }
}

function salir() {
    /**RESPETAR EL ORDEN SINO SE ROMPE */
    /*Primero oculta todas las secciones */
    ocultarSecciones();
    /*Luego muestra lo que deberia verse */
    document.querySelector("#seccionLogin").style.display = "block";
    document.querySelector("#seccionRegistro").style.display = "block";
    document.querySelector("#navPrincipal").style.display = "none";
    document.querySelector("#aux").style.display = "none";
    /*Luego oculta la seccion de registro */
    ocultarSeccionRegistro()
    /*Luego resetea los valores al salir*/
    usuarioLogeado = null;
    usuarioLogeadoAdmin = null;
}


//-------------------------------- LOGICA EJERCICIO--------------------------------------------------


let sistema = new Sistema();

function mostrarTabla() {
    document.querySelector("#tblPeliculas").innerHTML = "";
    for (let i = 0; i < sistema.peliculas.length; i++) {
        const unaPelicula = sistema.peliculas[i];
        let promedio = unaPelicula.votos / unaPelicula.votantes;
        if (promedio > 4) {
            document.querySelector("#tblPeliculas").innerHTML += `<tr>
            <td>${unaPelicula.nombre}</td>
            <td>${unaPelicula.anio}</td>
            <td>${promedio}</td>
            </tr>`
        }
    }
}
