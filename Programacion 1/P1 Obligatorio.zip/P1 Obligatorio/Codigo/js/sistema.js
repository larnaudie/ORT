class Sistema {
    constructor() {
        this.usuarios = [
            new Usuario(1, "Pablo", "123456"),
            new Usuario(2, "Natalia", "123456"),
            new Usuario(3, "usu3", "222"),
            new Usuario(4, "usu4", "111"),
        ];
        this.usuariosAdmin = [
            new Admin(0, "admin", "admin")
        ]
    }

    buscarNombre(arrElementos, propiedad, busqueda) {// usuarios, "nombre", "Pablo"
        let existe = false;

        for (let i = 0; i < arrElementos.length; i++) {
            const unElemento = arrElementos[i];
            const valorPropiedad = unElemento[propiedad]
            if (valorPropiedad.toLowerCase() === busqueda.toLowerCase()) {//usuarios[i].nombre === usuarios[i]["nombre"] => unaPelicula.nombre === unaPelicula["nombre"] === "spiderman"
                existe = true;
                break;
            }
        }
        return existe;
    }

    buscarElemento(arrElementos, propiedad, busqueda) {// usuarios, "nombre", "Pablo"
        let existe = false;

        for (let i = 0; i < arrElementos.length; i++) {
            const unElemento = arrElementos[i];
            if (unElemento[propiedad] === busqueda) {//usuarios[i].nombre === usuarios[i]["nombre"] => unaPelicula.nombre === unaPelicula["nombre"] === "spiderman"
                existe = true;
                break;
            }
        }
        return existe;
    }

    obtenerObjeto(arrElementos, propiedad, busqueda) {
        let objeto = null;
        for (let i = 0; i < arrElementos.length; i++) {
            const unElemento = arrElementos[i];
            if (unElemento[propiedad] === busqueda) {//peliculas[i].nombre === peliculas[i]["nombre"] => unaPelicula.nombre === unaPelicula["nombre"] === "spiderman"
                objeto = unElemento;
                break;
            }
        }
        return objeto;
    }

    //METODO VINCULADO AL REGISTRO
    validarCamposVaciosRegistro(nombre, clave) {
        let camposValidos = false;
        if (nombre !== "" && clave !== "") {
            camposValidos = true;
        }
        return camposValidos;
    }

    //METODO VINCULADO AL REGISTRO
    verificarFormatoContrasena(clave) {
        let valido = false;
        let contMayusculas = 0;
        let contMinusculas = 0;
        let contNumeros = 0;

        for (let i = 0; i < clave.length; i++) {

            if (clave.charAt(i) === clave.charAt(i).toUpperCase() && clave.charAt(1) !== " " && isNaN(clave.charAt(i))) {
                contMayusculas++;
            }

            if (clave.charAt(i) === clave.charAt(i).toLowerCase() && clave.charAt(1) !== " " && isNaN(clave.charAt(i))) {
                contMinusculas++;
            }

            if (!isNaN(clave.charAt(i))) {
                contNumeros++;
            }
        }

        if (clave.length > 5 && contMayusculas >= 1 && contMinusculas >= 1 && contNumeros >= 1) {
            valido = true;
        }

        return valido;
    }

    verificarCVC(numero) {
        let validar = false
        let contNumeros = 0;
        let contCaracterInvalido = 0;

        if (numero.length === 3) {
            for (let i = 0; i < numero.length; i++) {

                if (!isNaN(numero.charAt(i))) {
                    contNumeros++;
                } else {
                    contCaracterInvalido++;
                }
            }

            if (contNumeros === 3 && contCaracterInvalido === 0) {
                validar = true;
            }
        }
        return validar
    }

    verificarTarjetaCredito(numero) {
        let validar = false;
        let contNumerico = 0;
        let contGuiones = 0;
        let contCaracterInvalido = 0;
        if (numero.length < 19) {
            validar = false
        } else {
            for (let i = 0; i < numero.length; i++) {
                if (!isNaN(numero.charAt(i))) {
                    contNumerico++;
                } else if (numero.charAt(i) === "-") {
                    contGuiones++;
                } else {
                    contCaracterInvalido++;
                }
            }
            if (contNumerico === 16 && contCaracterInvalido === 0 && contGuiones === 3) {
                validar = true;
            }
        }
        return validar;
    }

    verificarTarjetaCreditoLuhn(numeroTarjeta) {
        let nroTarjeta = "";
        for (let i = 0; i < numeroTarjeta.length; i++) {
            if (numeroTarjeta.charAt(i) !== "-") {
                nroTarjeta += numeroTarjeta.charAt(i);
            }
        }

        let dev = false;
        let digitoVerificar = nroTarjeta.charAt(nroTarjeta.length - 1);
        let acumulador = 0;
        let cont = 0;
        for (let i = nroTarjeta.length - 2; i >= 0; i--) {
            let num = Number(nroTarjeta.charAt(i));
            if (cont % 2 === 0) {
                //se duplica
                let duplicado = num * 2;
                if (duplicado >= 10) {
                    // let duplicadoStr = String(duplicado);
                    // let resultado = Number(duplicadoStr.charAt(0)) + Number(duplicadoStr.charAt(1));
                    // acumulador += resultado;
                    acumulador += (duplicado - 9);
                } else {
                    acumulador += duplicado;
                }
            } else {
                //no se duplica
                acumulador += num;
            }
            cont++;
        }

        let multiplicado = acumulador * 9;
        let multiplicadoStr = String(multiplicado);
        let digitoVerificador = multiplicadoStr.charAt(multiplicadoStr.length - 1);

        if (digitoVerificar === digitoVerificador) {
            dev = true;
        }
        return dev;
    }

    //METODO VINCULADO AL REGISTRO
    agregarUsuario(usuario) {
        this.usuarios.push(usuario);
    }

    //METODO VINCULADO AL LOGIN
    /**Verificar Login, inicia el resultado en false, luego crea variable unUsuario el cual Accede al metodo obtenerObjeto
     * allí le pasa 3 parametros, 1) la lista de usuarios 2) el nombre de propiedad 3) el valor del nombre.
     */
    verificarLogin(nombre, clave, tipoUsuario) {
        let resultado = false;
        let unUsuario = this.obtenerObjeto(this.usuarios, "nombre", nombre);
        let unUsuarioAdmin = this.obtenerObjeto(this.usuariosAdmin, "nombre", nombre);

        if (tipoUsuario === "admin") {
            if (unUsuarioAdmin !== null) {
                if (clave === unUsuarioAdmin.contrasena) {
                    return resultado = true;
                }
            }

        } else {
            if (tipoUsuario === "user")
                if (unUsuario !== null) {
                    if (clave === unUsuario.contrasena) {
                        resultado = true;
                    }
                }
            return resultado;
        }
    }
}
