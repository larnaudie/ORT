class Partido {
    constructor(id, nombre){
        this.id = id;
        this.nombre = nombre;
        this.votos = 0;
        this.representantes = 0;
        this.votosCociente = 0;
        this.votosResiduo = 0;
    }
}