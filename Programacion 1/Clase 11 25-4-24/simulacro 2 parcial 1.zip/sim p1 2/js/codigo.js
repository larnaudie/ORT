window.addEventListener("load", inicio);

function inicio() {
	document.querySelector("#btnRegistro").addEventListener("click", registrarService);
	document.querySelector("#btnApariciones").addEventListener("click", cantidadApariciones);
}

let resultado = "";
let contadorMensajes = 0;

function registrarService() {
	let marcaModelo = document.querySelector("#txtModelo").value;
	let kilometros = Number(document.querySelector("#txtKilometros").value);
	let tipoService = document.querySelector("#slcService").value;
	let cantidadEspacios = 0;
	let costo = 0;

	if (contadorMensajes < 5) {
		for (let i = 0; i < marcaModelo.length; i++) {
			if (marcaModelo.charAt(i) === " ") {
				cantidadEspacios++;
			}
		}
		console.log(cantidadEspacios);
		if (marcaModelo.length >= 3 && marcaModelo.length <= 50 && marcaModelo.charAt(0) === marcaModelo.charAt(0).toUpperCase() &&
			marcaModelo.charAt(marcaModelo.length - 1) === marcaModelo.charAt(marcaModelo.length - 1).toLowerCase() && cantidadEspacios >= 1) {
			if (!isNaN(kilometros) && kilometros > 0) {
				if (tipoService === "premium") {
					costo = costo + 15000;
				} else if (tipoService === "advance") {
					costo = costo + 10000;
				} else {
					costo = costo + 5000;
				}

				if (kilometros >= 20000) {
					costo = costo + (costo * 0.15);
				} else if (kilometros >= 10000 && kilometros < 20000) {
					costo = costo + (costo * 0.10);
				}
				resultado += `El Modelo Marca del auto es ${marcaModelo} Tiene ${kilometros} Kilometros y el precio del services es de ${costo}<br>`;
				contadorMensajes++;
				document.querySelector("#pResultado").innerHTML = resultado;
			} else {
				document.querySelector("#pResultado").innerHTML = `Los kilometros deben de ser un valor numerico y ademas debe ser mayor a 0 <br>`;
			}
		} else {
			console.log('llego aca');
			document.querySelector("#pResultado").innerHTML = `Hay uno de estos posibles errores en el ingreso de datos:<br>
			*El marcaModelo ingresado no tiene entre 3 y 50 caracteres<br>
			*El marcaModelo no comienza en mayusculas<br>
			*El marcaModelo no termina en minusculas<br>
			*No hay espacios en marca modelo<br>`;
		}
	} else {
		document.querySelector("#pResultado").innerHTML = "Reinicie aplicacion ya el contador llego a " + contadorMensajes;
	}
}

function cantidadApariciones() {
	let texto = document.querySelector("#txtTexto").value;
	let textoMay = texto.toUpperCase();
	let contadorA = 0;
	let contadorE = 0;
	let contadorI = 0;
	let contadorO = 0;
	let contadorU = 0;
	let resultadoApariciones = "";

	for (let i = 0; i < textoMay.length; i++) {
		if (textoMay.charAt(i) === 'A') {
			contadorA++;
		}else if(textoMay.charAt(i) === 'E'){
			contadorE++
		}else if(textoMay.charAt(i) === 'I'){
			contadorI++
		}else if(textoMay.charAt(i) === 'O'){
			contadorO++
		}else if(textoMay.charAt(i) === 'U'){
			contadorU++
		}
	}
	
	let vocalMasFrecuente = 'A';
	let contadorMasFrecuente = contadorA;

	if (contadorE > contadorMasFrecuente) {
		vocalMasFrecuente = 'E';
		contadorMasFrecuente = contadorE;
	}
	if (contadorI > contadorMasFrecuente) {
		vocalMasFrecuente = 'I';
		contadorMasFrecuente = contadorI;
	}
	if (contadorO > contadorMasFrecuente) {
		vocalMasFrecuente = 'O';
		contadorMasFrecuente = contadorO;
	}
	if (contadorU > contadorMasFrecuente) {
		vocalMasFrecuente = 'U';
		contadorMasFrecuente = contadorU;
	}

	resultadoApariciones = `La vocal con más apariciones es '${vocalMasFrecuente}' con ${contadorMasFrecuente} apariciones.`;

	document.querySelector("#pResultado2").innerHTML = resultadoApariciones;
}