window.addEventListener("load", inicio);

function inicio(){
    document.querySelector("#btnMostrarEj12").addEventListener("click", contarMayusYMinus);
}

function contarMayusYMinus(){
    let texto = document.querySelector("#txtEj12").value;

    let textoSinEspacio = "";
    contadorMayusculas = 0;
    contadorMinusculas = 0;
      
    for(let i = 0; i < texto.length; i++){           
        if(texto.charAt(i) != " "){    
            let caracter = texto.charAt(i); 
            textoSinEspacio += caracter;           
        }
    }   
    
    for(let i = 0; i < textoSinEspacio.length; i++){ 
        if(textoSinEspacio.charCodeAt(i) >= 65 && textoSinEspacio.charCodeAt(i) <=90 ){ //if(stringSinEspacios.charCodeAt(i) <= 90)
            contadorMayusculas++;
        }
        if(textoSinEspacio.charCodeAt(i) >= 97 && textoSinEspacio.charCodeAt(i) <= 122){ //if(stringSinEspacios.charCodeAt(i) >= 91)
            contadorMinusculas++;
        }
    }
                                            
    document.querySelector("#pMostrarEj12").innerHTML = "Cantidad de mayusculas: " + contadorMayusculas + 
                                                        ". Cantidad de minusculas: " + contadorMinusculas;
}




